package DAO;

import model.Professor;
import model.Student;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public interface ProfessorDAO {

    List<Professor> getall() throws SQLException;

    List<Professor> getAllSortedById() throws SQLException;

    Map<String, Double> findAverageAgeByFaculty();

    Map<String, Integer> findProfessorCountBySubject();

    List<Student> findStudentsByUniversityId(int universityId);

    List<Student> findStudentsByFacultyId(int facultyId);

    Professor getByID(Long id) throws SQLException;

    void update(Professor professor) throws SQLException;

    void save(Professor professor) throws SQLException;

    void delete(Long id);

}
