package DAO.impl;

import DAO.JDBCUtils;
import DAO.StudentDAO;
import model.Student;
import model.Subject;

import java.sql.*;
        import java.util.ArrayList;
import java.util.List;

public class StudentDAOImpl implements StudentDAO {

    @Override
    public List<Student> getAll() throws SQLException {
        final String SELECT_ALL_STUDENT = "SELECT s.id, s.name, s.surname, s.location, s.indeks, " +
                "f.name AS facultyName, f.id AS faculty_id " +
                "FROM Student s LEFT JOIN Faculty f ON s.faculty_id = f.id;";

        List<Student> studentList = new ArrayList<>();

        try (Connection connection = JDBCUtils.getConnection();
             PreparedStatement ps = connection.prepareStatement(SELECT_ALL_STUDENT)) {

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                long id = rs.getLong("id");
                String name = rs.getString("name");
                String surname = rs.getString("surname");
                String location = rs.getString("location");
                int indeks = rs.getInt("indeks");
                String facultyName = rs.getString("facultyName");
                long faculty_id = rs.getLong("faculty_id");

                // Get passed subjects for this student
                List<Subject> passedSubjects = getPassedSubjectsForStudent(connection, id);

                Student student = new Student(id, name, surname, location, indeks, facultyName, faculty_id, passedSubjects);
                studentList.add(student);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching students: " + e.getMessage());
            throw e;
        }

        return studentList;
    }
    @Override
    public List<Student> getStudentsWithOddLengthNames() throws SQLException {
        final String QUERY = "SELECT id, name, surname, location, indeks, faculty_id FROM student WHERE LENGTH(name) % 2 = 1";
        List<Student> students = new ArrayList<>();

        try (Connection connection = JDBCUtils.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(QUERY)) {

            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                Long id = rs.getLong("id");
                String name = rs.getString("name");
                String surname = rs.getString("surname");
                String location = rs.getString("location"); // Can be null
                int indeks = rs.getInt("indeks");
                Long facultyId = rs.getObject("faculty_id") != null ? rs.getLong("faculty_id") : null; // Handle null faculty_id

                Student student = new Student(id, name, surname, location, indeks, facultyId);
                students.add(student);

                // Debugging
                System.out.println("Fetched: " + id + ", " + name + ", " + surname + ", " +
                        (location != null ? location : "NULL") + ", " + indeks + ", " + (facultyId != null ? facultyId : "NULL"));
            }
        }
        return students;
    }


    private List<Subject> getPassedSubjectsForStudent(Connection connection, long studentId) throws SQLException {
        List<Subject> subjects = new ArrayList<>();
        String query = "SELECT s.id, s.name FROM Subject s " +
                "JOIN student_subject ss ON s.id = ss.subject_id " +
                "WHERE ss.student_id = ?";

        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setLong(1, studentId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Subject subject = new Subject();
                subject.setId(rs.getLong("id"));
                subject.setName(rs.getString("name"));
                subjects.add(subject);
            }
        }

        return subjects;
    }

    @Override
    public Student getStudentById(Long id) throws SQLException {
        final String QUERY = "SELECT s.id, s.name, s.surname, s.indeks, s.location, f.name AS faculty_name, s.faculty_id " +
                "FROM Student s LEFT JOIN Faculty f ON s.faculty_id = f.id " +
                "WHERE s.id = ?";

        try (Connection connection = JDBCUtils.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(QUERY)) {
            preparedStatement.setLong(1, id);
            ResultSet rs = preparedStatement.executeQuery();

            if (rs.next()) {
                String name = rs.getString("name");
                String surname = rs.getString("surname");
                String location = rs.getString("location");
                int indeks = rs.getInt("indeks");
                String facultyName = rs.getString("faculty_name");
                Long facultyId = rs.getLong("faculty_id");
                List<Subject> passedSubjects = getPassedSubjectsForStudent(connection, id);

                return new Student(id, name, surname, location, indeks, facultyName, facultyId, passedSubjects);
            } else {
                System.out.println("No student found with ID " + id);
                return null;
            }
        }
    }

    @Override
    public Student getByID(Long id) throws SQLException {
        // Optional: you can redirect this to getStudentById for consistency
        return getStudentById(id);
    }

    @Override
    public void save(Student student) throws SQLException {
        final String INSERT_STUDENT_SQL = "INSERT INTO Student (name, surname, location, indeks, faculty_id) VALUES (?, ?, ?, ?, ?)";

        try (Connection connection = JDBCUtils.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_STUDENT_SQL, Statement.RETURN_GENERATED_KEYS)) {

            preparedStatement.setString(1, student.getName());
            preparedStatement.setString(2, student.getSurname());
            preparedStatement.setString(3, student.getLocation());
            preparedStatement.setInt(4, student.getIndeks());
            preparedStatement.setLong(5, student.getFacultyId());
            preparedStatement.executeUpdate();

            ResultSet generatedKeys = preparedStatement.getGeneratedKeys();
            if (generatedKeys.next()) {
                long studentId = generatedKeys.getLong(1);
                student.setId(studentId);

                // Insert passedSubjects associations
                insertStudentSubjects(connection, studentId, student.getPassedSubjects());
            }
        }
    }

    private void insertStudentSubjects(Connection connection, long studentId, List<Subject> subjects) throws SQLException {
        if (subjects == null || subjects.isEmpty()) return;

        String insertSQL = "INSERT INTO student_subject (student_id, subject_id) VALUES (?, ?)";

        try (PreparedStatement ps = connection.prepareStatement(insertSQL)) {
            for (Subject subject : subjects) {
                ps.setLong(1, studentId);
                ps.setLong(2, subject.getId()); // Make sure Subject objects have id set
                ps.addBatch();
            }
            ps.executeBatch();
        }
    }

    @Override
    public void update(Student student) throws SQLException {
        final String UPDATE_STUDENT_SQL = "UPDATE Student SET name = ?, surname = ?, location = ?, indeks = ?, faculty_id = ? WHERE id = ?";

        try (Connection connection = JDBCUtils.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_STUDENT_SQL)) {

            preparedStatement.setString(1, student.getName());
            preparedStatement.setString(2, student.getSurname());
            preparedStatement.setString(3, student.getLocation());
            preparedStatement.setInt(4, student.getIndeks());
            preparedStatement.setLong(5, student.getFacultyId());
            preparedStatement.setLong(6, student.getId());
            preparedStatement.executeUpdate();

            // Delete old subject associations
            deleteStudentSubjects(connection, student.getId());

            // Insert new subject associations
            insertStudentSubjects(connection, student.getId(), student.getPassedSubjects());
        }
    }

    private void deleteStudentSubjects(Connection connection, long studentId) throws SQLException {
        String deleteSQL = "DELETE FROM student_subject WHERE student_id = ?";
        try (PreparedStatement ps = connection.prepareStatement(deleteSQL)) {
            ps.setLong(1, studentId);
            ps.executeUpdate();
        }
    }

    @Override
    public void delete(Long id) throws SQLException {
        final String DELETE_ASSOCIATIONS = "DELETE FROM student_subject WHERE student_id = ?";
        final String DELETE_STUDENT_SQL = "DELETE FROM Student WHERE id = ?";

        try (Connection connection = JDBCUtils.getConnection()) {
            // Delete associations first
            try (PreparedStatement ps1 = connection.prepareStatement(DELETE_ASSOCIATIONS)) {
                ps1.setLong(1, id);
                ps1.executeUpdate();
            }

            // Delete student
            try (PreparedStatement ps2 = connection.prepareStatement(DELETE_STUDENT_SQL)) {
                ps2.setLong(1, id);
                int rowsAffected = ps2.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Student with ID " + id + " was deleted successfully!");
                } else {
                    System.out.println("No Student found with ID " + id);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error deleting Student: " + e.getMessage());
            throw e;
        }
    }
}

