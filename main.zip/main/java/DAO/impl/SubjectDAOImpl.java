package DAO.impl;

import DAO.JDBCUtils;
import DAO.SubjectDAO;
import model.Subject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SubjectDAOImpl implements SubjectDAO {

    @Override
    public List<Subject> getAll() throws SQLException {
        final String SELECT_ALL_SUBJECT = "SELECT * FROM Subject;";

        List<Subject> subjectList = new ArrayList<>();
        try (Connection connection = JDBCUtils.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_SUBJECT)) {

            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                long id = rs.getLong("id");
                String name = rs.getString("name");
                String semester = rs.getString("semester");
                int credits = rs.getInt("credits");

                // Properly handle nullable studentId
                Long studentId = null;
                long tempStudentId = rs.getLong("studentId");
                if (!rs.wasNull()) {
                    studentId = tempStudentId;
                }

                // Properly handle nullable grade
                Integer grade = null;
                int tempGrade = rs.getInt("grade");
                if (!rs.wasNull()) {
                    grade = tempGrade;
                }

                Subject subject = new Subject();
                subject.setId(id);
                subject.setName(name);
                subject.setSemester(semester);
                subject.setCredits(credits);
                subject.setStudentId(studentId);
                subject.setGrade(grade);

                subjectList.add(subject);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching Subjects: " + e.getMessage());
            throw e;
        }
        return subjectList;
    }

    @Override
    public List<Subject> getSubjectsByProfessorId(Long professorId) throws SQLException {
        final String SELECT_SUBJECTS_BY_PROFESSOR = "SELECT * FROM Subject WHERE professor_id = ?;";

        List<Subject> subjectList = new ArrayList<>();
        try (Connection connection = JDBCUtils.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_SUBJECTS_BY_PROFESSOR)) {

            preparedStatement.setLong(1, professorId);

            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                long id = rs.getLong("id");
                String name = rs.getString("name");
                String semester = rs.getString("semester");
                Integer credits = rs.getInt("credits");

                Subject subject = new Subject(id, name, semester, credits);
                subjectList.add(subject);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching Subjects by professor: " + e.getMessage());
            throw e;
        }
        return subjectList;
    }

    public List<Subject> getPassedSubjectsByStudentId(Long studentId) throws SQLException {
        final String QUERY = "SELECT sub.id, sub.name, sub.semester, sub.credits, ss.grade " +
                "FROM Subject sub " +
                "JOIN student_subject ss ON sub.id = ss.subject_id " +
                "WHERE ss.student_id = ?";

        List<Subject> subjects = new ArrayList<>();
        try (Connection connection = JDBCUtils.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(QUERY)) {

            preparedStatement.setLong(1, studentId);

            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                Long id = rs.getLong("id");
                String name = rs.getString("name");
                String semester = rs.getString("semester");
                Integer credits = rs.getInt("credits");
                Integer grade = rs.getInt("grade");
                if (rs.wasNull()) grade = null;

                Subject subject = new Subject(id, name, semester, credits, null, grade);
                subjects.add(subject);
            }
        }
        return subjects;
    }

    @Override
    public Subject getByID(Long id) throws SQLException {
        final String SELECT_BY_ID = "SELECT * FROM Subject WHERE id = ?;";
        Subject subject = null;

        try (Connection connection = JDBCUtils.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_BY_ID)) {

            preparedStatement.setLong(1, id);
            ResultSet rs = preparedStatement.executeQuery();

            if (rs.next()) {
                String name = rs.getString("name");
                String semester = rs.getString("semester");
                int credits = rs.getInt("credits");

                Long studentId = null;
                long tempStudentId = rs.getLong("studentId");
                if (!rs.wasNull()) {
                    studentId = tempStudentId;
                }

                Integer grade = null;
                int tempGrade = rs.getInt("grade");
                if (!rs.wasNull()) {
                    grade = tempGrade;
                }

                subject = new Subject(id, name, semester, credits, studentId, grade);

                System.out.println("Fetched Subject: " + id + ", " + name + ", " + semester + ", " + credits + ", studentId=" + studentId + ", grade=" + grade);
            } else {
                System.out.println("No Subject found with ID " + id);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching Subject: " + e.getMessage());
            throw e;
        }
        return subject;
    }

    @Override
    public void update(Subject subject) throws SQLException {
        final String UPDATE_SUBJECT_SQL = "UPDATE Subject SET name = ?, semester = ?, credits = ?, studentId = ?, grade = ? WHERE id = ?;";

        try (Connection connection = JDBCUtils.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_SUBJECT_SQL)) {

            preparedStatement.setString(1, subject.getName());
            preparedStatement.setString(2, subject.getSemester());
            preparedStatement.setInt(3, subject.getCredits());

            if (subject.getStudentId() != null) {
                preparedStatement.setLong(4, subject.getStudentId());
            } else {
                preparedStatement.setNull(4, java.sql.Types.BIGINT);
            }

            if (subject.getGrade() != null) {
                preparedStatement.setInt(5, subject.getGrade());
            } else {
                preparedStatement.setNull(5, java.sql.Types.INTEGER);
            }

            preparedStatement.setLong(6, subject.getId());

            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            System.err.println("Error updating Subject: " + e.getMessage());
            throw e;
        }
    }

    @Override
    public void save(Subject subject) throws SQLException {
        final String INSERT_SUBJECT_SQL = "INSERT INTO Subject (name, semester, credits, studentId, grade) VALUES (?, ?, ?, ?, ?);";

        try (Connection connection = JDBCUtils.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_SUBJECT_SQL)) {

            preparedStatement.setString(1, subject.getName());
            preparedStatement.setString(2, subject.getSemester());
            preparedStatement.setInt(3, subject.getCredits());

            if (subject.getStudentId() != null) {
                preparedStatement.setLong(4, subject.getStudentId());
            } else {
                preparedStatement.setNull(4, java.sql.Types.BIGINT);
            }

            if (subject.getGrade() != null) {
                preparedStatement.setInt(5, subject.getGrade());
            } else {
                preparedStatement.setNull(5, java.sql.Types.INTEGER);
            }

            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            System.err.println("Error inserting Subject: " + e.getMessage());
            throw e;
        }
    }

    @Override
    public void delete(Long id) throws SQLException {
        final String DELETE_SUBJECT_SQL = "DELETE FROM Subject WHERE id = ?;";

        try (Connection connection = JDBCUtils.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(DELETE_SUBJECT_SQL)) {

            preparedStatement.setLong(1, id);
            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Subject with ID " + id + " was deleted successfully!");
            } else {
                System.out.println("No Subject found with ID " + id);
            }
        } catch (SQLException e) {
            System.err.println("Error deleting Subject: " + e.getMessage());
            throw e;
        }
    }
}
