package DAO;

import java.sql.*;

public class JDBCUtils {

//    public static Connection getConnection() throws SQLException {
//        final String URL = "jdbc:mysql://localhost:3306/Education?useSSL=false&allowPublicKeyRetrieval=true";
//        final String USER = "root";
//        final String PASSWORD = "12345Em!";
//
//        return DriverManager.getConnection(URL, USER, PASSWORD);
//    }

    public static Connection conn = null;
    static {
        final String URL = "jdbc:mysql://localhost:3306/Education?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC&autoReconnect=true";
        final String USER = "root";
        final String PASSWORD = "12345Em!";
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn =  DriverManager.getConnection(URL, USER, PASSWORD);
        }
        catch (ClassNotFoundException e) {
            throw new RuntimeException("Failed to load MySQL JDBC driver", e);}
        catch(SQLException e){
            throw new RuntimeException(e);
        }
        System.out.println("Connected to database");
    }
    public static Connection getConnection(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            String unicode="useSSL=false&autoReconnect=true&useUnicode=yes&characterEncoding=UTF-8";
            return DriverManager.getConnection("jdbc:mysql://localhost:3306/Education?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC&autoReconnect=true"+unicode, "root", "12345Em!");
        }catch(Exception ex){
            System.out.println(ex.getMessage());
            System.out.println("couldn't connect!");
            throw new RuntimeException(ex);
        }    }

    public static void printSQLException(SQLException ex) {
        for (Throwable e : ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }

    public static void main(String[] args) throws SQLException {
         String URL = "jdbc:mysql://localhost:3306/Education?useSSL=false&allowPublicKeyRetrieval=true";
         String USER = "root";
         String PASSWORD = "12345Em!";

         try(Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
         Statement stmt = conn.createStatement()) {


//

//               String query3 ="SELECT s.id, s.name as sName, s.surname as sSurname, p.id as pId, p.name as pName, p.surname as pSurname FROM student s JOIN professor p ON s.professor_id = p.id WHERE professor_id = 11; ";
//               ResultSet rs3 = stmt.executeQuery(query3);
//               while (rs3.next()) {
//                   int StudentId = rs3.getInt("id");
//                   String sName = rs3.getString("sName");
//                   String sSurname = rs3.getString("sSurname");
//                   int ProffesorId = rs3.getInt("pId");
//                   String pName = rs3.getString("pName");
//                   String pSurname = rs3.getString("pSurname");
//
//                     System.out.println("StudentId: " + StudentId + ", Name: " + sName + ", Surname: " + sSurname + ", ProffesorId: " + ProffesorId + ", pName:" + pName + ", pSurname:" + pSurname);
//               }

//

//

//             String query6 ="SELECT s2.id as student_id, SUM(s.credits) as total_credits FROM subject s JOIN student s2 ON s2.id = s.studentId  GROUP BY s2.id;";
//             ResultSet rs6 = stmt.executeQuery(query6);
//             while (rs6.next()) {
//                 int student_id = rs6.getInt("student_id");
//                 int total_credits = rs6.getInt("total_credits");
//
//                 System.out.println("student_id: " + student_id + ", total_credits: " +  total_credits);
//             }

//             String query7 = "SELECT s2.* FROM student s1 JOIN subject s2 ON s1.id = s2.studentId;";
//             ResultSet rs7 = stmt.executeQuery(query7);
//             while (rs7.next()) {
//                 int subjectId = rs7.getInt("id");
//                 String subjectName = rs7.getString("name");
//                 String semester = rs7.getString("semester");
//                 int credits = rs7.getInt("credits");
//                 int studentId = rs7.getInt("studentId");
//
//
//                 System.out.println("subjectId: " + subjectId + ", subjectName: " + subjectName + ", semester: " + semester + ", credits: " + credits + ", studentId: " + studentId);
//             }

         }catch (SQLException ex) {
             printSQLException(ex);
         }

    }
}