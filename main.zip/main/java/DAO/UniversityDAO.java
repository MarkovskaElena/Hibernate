package DAO;


import model.University;

import java.sql.SQLException;
import java.util.List;

public interface UniversityDAO {

    List<University> getAll() throws SQLException;

    List<University> getUniversitiesInSkopje() throws SQLException;

    University getByID(Long id) throws SQLException;

    void update(University university) throws SQLException;

    University save(University university) throws SQLException;

    void delete(Long id) throws SQLException;

}
