package DAO;

import model.Faculty;

import java.sql.SQLException;
import java.util.List;

public interface FacultyDAO {

    List<Faculty> getAll() throws SQLException;

    Faculty getByID(Long id) throws SQLException;

    void update(Faculty faculty) throws SQLException;

    void save(Faculty faculty) throws SQLException;

    void delete(Long id) throws SQLException;
}
