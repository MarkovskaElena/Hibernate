package DAO;

import model.Student;
import model.Subject;

import java.sql.SQLException;
import java.util.List;

public interface StudentDAO {

    List<Student> getAll() throws SQLException;

    List<Student> getStudentsWithOddLengthNames() throws SQLException;

    Student getStudentById(Long id) throws SQLException;

    Student getByID(Long id) throws SQLException;

    void update(Student student) throws SQLException;

    void save(Student student) throws SQLException;

    void delete(Long id) throws SQLException;

}
