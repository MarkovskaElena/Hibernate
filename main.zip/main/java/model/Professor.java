package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Professor {

    private Long id;
    private String name;
    private String surname;
    private int age;
    private String primarySubject;
    private String secondarySubject;
    private List<Student> students = new ArrayList<>();
    private List<Subject> subjects = new ArrayList<>();

    // Constructor without students parameter
    public Professor(Long id, String name, String surname, int age, String primarySubject, String secondarySubject) {
        this.id = id;
        this.name = name;
        this.surname = surname;
        this.age = age;
        this.primarySubject = primarySubject;
        this.secondarySubject = secondarySubject;
    }

    // Constructor with students parameter (optional, in case you want to provide the list)
    public Professor(Long id, String name, String surname, int age, String primarySubject, String secondarySubject, List<Student> students) {
        this.id = id;
        this.name = name;
        this.surname = surname;
        this.age = age;
        this.primarySubject = primarySubject;
        this.secondarySubject = secondarySubject;
        this.students = students != null ? students : new ArrayList<>();
        this.subjects = subjects != null ? subjects : new ArrayList<>();
    }

    public Professor() {
    }

    public List<Subject> getSubjects() {
        return subjects;
    }

    public void setSubjects(List<Subject> subjects) {
        this.subjects = subjects;
    }

    public List<Student> getStudents() {
        return students;
    }

    public void setStudents(List<Student> students) {
        this.students = students;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getPrimarySubject() {
        return primarySubject;
    }

    public void setPrimarySubject(String primarySubject) {
        this.primarySubject = primarySubject;
    }

    public String getSecondarySubject() {
        return secondarySubject;
    }

    public void setSecondarySubject(String secondarySubject) {
        this.secondarySubject = secondarySubject;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Professor professor = (Professor) o;
        return age == professor.age && Objects.equals(id, professor.id) && Objects.equals(name, professor.name) && Objects.equals(surname, professor.surname) && Objects.equals(primarySubject, professor.primarySubject) && Objects.equals(secondarySubject, professor.secondarySubject) && Objects.equals(students, professor.students);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, surname, age, primarySubject, secondarySubject, students);
    }

    @Override
    public String toString() {
        return id + " " + name + " " + surname + " " + age + " " + primarySubject + " " + secondarySubject;
    }
}
