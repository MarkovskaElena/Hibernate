package model;

import java.util.Objects;

public class Faculty {

    private Long id;

    private String name;

    private String location;

    private String studyField;

    private Long universityId;

    public Faculty(Long id, String name, String location, String studyField, Long universityId) {
        this.id = id;
        this.name = name;
        this.location = location;
        this.studyField = studyField;
        this.universityId = universityId;
    }
    public Faculty() {}

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getStudyField() {
        return studyField;
    }

    public void setStudyField(String studyField) {
        this.studyField = studyField;
    }

    public Long getUniversityId() {
        return universityId;
    }
    public void setUniversityId(Long universityId) {
        this.universityId = universityId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Faculty faculty = (Faculty) o;
        return Objects.equals(id, faculty.id) && Objects.equals(name, faculty.name) && Objects.equals(location, faculty.location) && Objects.equals(studyField, faculty.studyField) && Objects.equals(universityId, faculty.universityId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, location, studyField, universityId);
    }

    @Override
    public String toString() {
        return id + ", " + name + ", " + location + ", " + studyField + ", University ID: " + universityId;
    }
}
