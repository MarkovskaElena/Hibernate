package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Student {
    private Long id;

    private String name;

    private String surname;

    private String location;

    private int indeks;

    private String facultyName;

    private Long facultyId;

    public List<Subject> getPassedSubjects() {
        return passedSubjects;
    }

    public void setPassedSubjects(List<Subject> passedSubjects) {
        this.passedSubjects = passedSubjects;
    }

    private List<Subject> passedSubjects = new ArrayList<>();

    public Student(Long id, String name, String surname, String location, int indeks, String facultyName, Long facultyId, List<Subject> passedSubjects) {
        this.id = id;
        this.name = name;
        this.surname = surname;
        this.location = location;
        this.indeks = indeks;
        this.facultyName = facultyName;
        this.facultyId = facultyId;
        this.passedSubjects = passedSubjects;
    }


    public Student() {
    }

    public <E> Student(Long id, String name, String surname, String location, String index, String facultyName, Long grade, ArrayList<E> es) {
    }

    public Student(long id, String name, String surname, String location, Integer indeks) {
    }

    public Student(Long id, String name, String surname, String location, int indeks, Long facultyId) {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public int getIndeks() {
        return indeks;
    }

    public void setIndeks(int indeks) {
        this.indeks = indeks;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getFacultyName() {
        return facultyName;
    }

    public void setFacultyName(String facultyName) {
        this.facultyName = facultyName;
    }
    public Long getFacultyId() {
        return facultyId;
    }

    public void setFacultyId(Long facultyId) {
        this.facultyId = facultyId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Student student = (Student) o;
        return indeks == student.indeks && Objects.equals(id, student.id) && Objects.equals(name, student.name) && Objects.equals(surname, student.surname) && Objects.equals(location, student.location) && Objects.equals(facultyName, student.facultyName) && Objects.equals(facultyId, student.facultyId) && Objects.equals(passedSubjects, student.passedSubjects);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, surname, location, indeks, facultyName, facultyId, passedSubjects);
    }

    @Override
    public String toString(){
        return id + " " + name + " " + surname + " " + location + " " + indeks;
    }
}
