package model;

import java.util.Objects;

public class Subject {
    private Long id;

    private String name;

    private String semester;

    private int credits;

    private Long studentId;

    private Integer grade;


    public Subject(Long id, String name, String semester, int credits, Long studentId, Integer grade) {
        this.id = id;
        this.name = name;
        this.semester = semester;
        this.credits = credits;
        this.studentId = studentId;
        this.grade = grade;
    }

    public Subject(long id, String name, String semester, Integer credits) {
    }

    public Subject() {

    }

    public Subject(Long id, String name, String semester, Integer credits, int grade) {
    }

    public Integer getGrade() {
        return grade;
    }

    public void setGrade(Integer grade) {
        this.grade = grade;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSemester() {
        return semester;
    }

    public void setSemester(String semester) {
        this.semester = semester;
    }

    public int getCredits() {
        return credits;
    }

    public void setCredits(int credits) {
        this.credits = credits;
    }

    public Long getStudentId() {
        return studentId;
    }

    public void setStudentId(Long studentId) {
        this.studentId = studentId;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Subject subject = (Subject) o;
        return credits == subject.credits && Objects.equals(id, subject.id) && Objects.equals(name, subject.name) && Objects.equals(semester, subject.semester) && Objects.equals(studentId, subject.studentId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, semester, credits, studentId);
    }

    @Override
    public String toString() {
        return id + " " + name + " " + semester + " " + credits + " " + studentId;
    }

}


