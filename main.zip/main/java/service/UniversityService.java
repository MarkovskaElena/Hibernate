package service;

import model.University;

import java.sql.SQLException;
import java.util.List;

public interface UniversityService {

    List<University> getAllFaculty() throws SQLException;

    List<University> getAllUniversities() throws SQLException;

    University getById(Long id) throws SQLException;

    void update(University university);

    void delete(Long id) throws SQLException;

    void save(University university);

}
