package service.impl;

import DAO.JDBCUtils;
import DAO.impl.SubjectDAOImpl;
import model.Subject;
import service.SubjectService;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SubjectServiceImpl implements SubjectService {

    SubjectDAOImpl subjectDAO = new SubjectDAOImpl();

    @Override
    public List<Subject> getAllSubjects() throws SQLException {
        List<Subject> subject = subjectDAO.getAll();
        return subject;
    }


    @Override
    public Subject getById(Long id) throws SQLException {
        final String SELECT_SUBJECT_BY_ID = "SELECT * FROM Subject WHERE id = ?";
        try (Connection connection = JDBCUtils.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_SUBJECT_BY_ID)) {
            preparedStatement.setLong(1, id);
            ResultSet rs = preparedStatement.executeQuery();

            if (rs.next()) {
                String name = rs.getString("name");
                String semester = rs.getString("semester");
                int credits = rs.getInt("credits");
                Long studentId = rs.getLong("studentId");
                Integer grade = rs.getInt("grade");  // if grade column exists

                return new Subject(id, name, semester, credits, studentId, grade);
            } else {
                return null; // no subject found
            }
        } catch (SQLException e) {
            System.err.println("Error fetching Subject by ID: " + e.getMessage());
            throw e;
        }
    }


    @Override
    public void update(Subject subject) {
        try {
            subjectDAO.update(subject);
            System.out.println("Successfully updated subject: " + subject);
        } catch (SQLException e) {
            System.out.println("Error updating subject: " + subject + ". " + e.getMessage());
            throw new RuntimeException("Failed to update subject", e);
        }
    }

    @Override
    public void delete(Long id) throws SQLException {
        subjectDAO.delete(id);
        System.out.println("Successfully deleted subject with ID: " + id);
    }

    @Override
    public void save(Subject subject) {
        try {
            subjectDAO.save(subject);
            System.out.println("Successfully saved subject: " + subject);
        } catch (SQLException e) {
            System.out.println("Error saving subject: " + subject + ". " + e.getMessage());
            throw new RuntimeException("Failed to save subject", e);
        }
    }
}