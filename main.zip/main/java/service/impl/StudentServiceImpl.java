package service.impl;

import DAO.impl.StudentDAOImpl;
import model.Student;
import service.StudentService;

import java.sql.SQLException;
import java.util.List;

public class StudentServiceImpl implements StudentService {

    StudentDAOImpl studentDAO = new StudentDAOImpl();

    @Override
    public List<Student> getAllStudent() throws SQLException {
        List<Student> student = studentDAO.getAll();
        return student;
    }

    @Override
    public Student getById(Long id) throws SQLException {
       try{
           return studentDAO.getByID(id);
       } catch (SQLException e) {
           System.out.println("Error fetching student with ID " + id + ": " + e.getMessage());
           throw e;
       }
    }

    @Override
    public void update(Student student) {
        try {
            studentDAO.update(student);
            System.out.println("Successfully updated student: " + student);
        } catch (SQLException e) {
            System.out.println("Error updating student: " + student + ". " + e.getMessage());
            throw new RuntimeException("Failed to update student", e);
        }
    }

    @Override
    public void delete(Long id) throws SQLException {
        studentDAO.delete(id);
        System.out.println("Successfully deleted student with ID: " + id);
    }

    @Override
    public void save(Student student) {
        try {
            studentDAO.save(student);
            System.out.println("Successfully saved student: " + student);
        } catch (SQLException e) {
            System.out.println("Error saving student: " + student + ". " + e.getMessage());
            throw new RuntimeException("Failed to save student", e);
        }
    }
}
