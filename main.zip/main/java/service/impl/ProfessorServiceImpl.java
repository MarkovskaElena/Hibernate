package service.impl;

import DAO.impl.ProfessorDAOImpl;
import model.Professor;
import service.ProfessorService;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

public class ProfessorServiceImpl implements ProfessorService {

    private final ProfessorDAOImpl professorDAO;

    public ProfessorServiceImpl() {
        this.professorDAO = new ProfessorDAOImpl();
    }

    public class DatabaseConnection {
        public Connection getConnection() throws SQLException {
            return DriverManager.getConnection("jdbc:mysql://localhost:3306/Education?useSSL=false&allowPublicKeyRetrieval=true", "root", "12345Em!");
        }
    }

    @Override
    public List<Professor> getAllFaculty() throws SQLException {
        List<Professor> professor = professorDAO.getall();
        return professor;
    }

    @Override
    public Professor getById(Long id) throws SQLException {
        try {
            return professorDAO.getByID(id);
        } catch (SQLException e) {
            System.out.println("Error fetching professor with ID " + id + ": " + e.getMessage());
            throw e;
        }
    }

    @Override
    public void update(Professor professor) {
        try {
            professorDAO.update(professor);
            System.out.println("Successfully updated professor: " + professor);
        } catch (SQLException e) {
            System.out.println("Error updating professor: " + professor + ". " + e.getMessage());
            throw new RuntimeException("Failed to update professor", e);
        }
    }

    @Override
    public void delete(Long id) {
        professorDAO.delete(id);
        System.out.println("Successfully deleted professor with ID: " + id);
    }

    @Override
    public void save(Professor professor) {
        try {
            professorDAO.save(professor);
            System.out.println("Successfully saved professor: " + professor);
        } catch (SQLException e) {
            System.out.println("Error saving professor: " + professor + ". " + e.getMessage());
            throw new RuntimeException("Failed to save professor", e);
        }
    }
}
