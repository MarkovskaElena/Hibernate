package controller;

import DAO.FacultyDAO;
import DAO.StudentDAO;
import DAO.impl.FacultyDAOImpl;
import DAO.impl.StudentDAOImpl;
import model.Faculty;
import model.Student;
import model.Subject;
import model.University;
import service.FacultyService;
import service.StudentService;
import service.UniversityService;
import service.impl.FacultyServiceImpl;
import service.impl.StudentServiceImpl;
import service.impl.UniversityServiceImpl;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.*;


@WebServlet("/")
public class StudentServlet extends HttpServlet{

    private static final long serialVersionUID = 1L;
    private StudentService studentService;
    private FacultyService facultyService;
    private StudentDAO studentDAO;

    public StudentServlet() {
        this.studentService = new StudentServiceImpl();
        this.facultyService = new FacultyServiceImpl();
        this.studentDAO = new StudentDAOImpl();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //doGet(request, response);
        //response.sendRedirect("faculty-form.jsp");
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getPathInfo();
        if (action == null) {
            action = "/list";
        }

        try {
            switch (action) {
                case "/new":
                    showNewForm(request, response);
                    break;
                case "/insert":
                    insertStudent(request, response);
                    break;
                case "/delete":
                    deleteStudent(request, response);
                    break;
                case "/edit":
                    showEditForm(request, response);
                    break;
                case "/update":
                    updateStudent(request, response);
                    break;
                case "/list":
                    listStudent(request, response);
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }

    private void listStudent(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        List<Student> listStudent = studentDAO.getAll();

        request.setAttribute("listStudent", listStudent);
        RequestDispatcher dispatcher = request.getRequestDispatcher("pages/student-list.jsp");
        dispatcher.forward(request, response);
    }


    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }


    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        Long id = Long.parseLong(request.getParameter("id"));

        Student existingStudent = studentService.getById(id);

        if (existingStudent == null) {
            System.out.println("No student found with ID: " + id);
            response.sendError(HttpServletResponse.SC_NOT_FOUND, "Student not found");
            return;
        }

        request.setAttribute("student", existingStudent);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/student-form.jsp");
        dispatcher.forward(request, response);
    }



    private void insertStudent(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        String name = request.getParameter("name");
        String surname = request.getParameter("surname");
        String location = request.getParameter("location");
        Integer indeks = Integer.parseInt(request.getParameter("indeks"));
        String facultyName = request.getParameter("facultyName");
        Long facultyId = Long.parseLong(request.getParameter("facultyId"));
        String[] passedSubjectsArray = request.getParameterValues("passedSubjects");
        List<Subject> passedSubjects = new ArrayList<>();
        if (passedSubjectsArray != null) {
            for (String subjectName : passedSubjectsArray) {
                Subject subject = new Subject();
                subject.setName(subjectName);
                passedSubjects.add(subject);
            }
        }
        Student student = new Student(null, name, surname, location, indeks, facultyName, facultyId, passedSubjects);
        studentService.save(student);
        response.sendRedirect(request.getContextPath() + "/list");
    }

    private void updateStudent(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        String idStr = request.getParameter("id");
        Long id = Long.parseLong(idStr);
        String name = request.getParameter("name");
        String surname = request.getParameter("surname");
        String location = request.getParameter("location");
        Integer indeks = Integer.parseInt(request.getParameter("indeks"));
        String facultyName = request.getParameter("facultyName");
        Long facultyId = Long.parseLong(request.getParameter("facultyId"));
        String[] passedSubjectsArray = request.getParameterValues("passedSubjects");
        List<Subject> passedSubjects = new ArrayList<>();

        Student student = new Student(null, name, surname, location, indeks, facultyName, facultyId, passedSubjects);
        studentService.update(student);
        response.sendRedirect(request.getContextPath() + "/list");
    }

    private void deleteStudent(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        Long id = Long.parseLong(request.getParameter("id"));
        facultyService.delete(id);

        List<Student> listStudent = studentService.getAllFaculty();
        request.getSession().setAttribute("listStudent", listStudent);
        response.sendRedirect(request.getContextPath() + "/list");
    }

}