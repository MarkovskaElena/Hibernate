//package controller;
//
//import DAO.StudentDAO;
//import DAO.impl.StudentDAOImpl;
//import model.Faculty;
//import model.Student;
//import model.Subject;
//import service.FacultyService;
//import service.ProfessorService;
//import service.StudentService;
//import service.SubjectService;
//import service.impl.FacultyServiceImpl;
//import service.impl.ProfessorServiceImpl;
//import service.impl.StudentServiceImpl;
//import service.impl.SubjectServiceImpl;
//
//import javax.servlet.RequestDispatcher;
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//import java.io.IOException;
//import java.sql.SQLException;
//import java.util.*;
//import java.util.stream.Collectors;
//
//public class StudentServlet extends HttpServlet {
//
//    private static final long serialVersionUID = 1L;
//
//    private final StudentService studentService = new StudentServiceImpl();
//    private final FacultyService facultyService = new FacultyServiceImpl();
//    private final ProfessorService professorService = new ProfessorServiceImpl();
//    private final SubjectService subjectService = new SubjectServiceImpl();
//
//
//    @Override
//    protected void doPost(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        doGet(request, response);
//    }
//
//    @Override
//    protected void doGet(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//
//        String action = Optional.ofNullable(request.getPathInfo()).orElse("/list");
//
//        try {
//            switch (action) {
//                case "/new":
//                    showNewForm(request, response);
//                    break;
//                case "/insert":
//                    insertStudent(request, response);
//                    break;
//                case "/delete":
//                    deleteStudent(request, response);
//                    break;
//                case "/edit":
//                    showEditForm(request, response);
//                    break;
//                case "/update":
//                    updateStudent(request, response);
//                    break;
//                case "/list":
//                default:
//                    listStudent(request, response);
//                    break;
//            }
//        } catch (SQLException ex) {
//            throw new ServletException("Database error: " + ex.getMessage(), ex);
//        }
//    }
//
//    private void listStudent(HttpServletRequest request, HttpServletResponse response)
//            throws SQLException, IOException, ServletException {
//        List<Student> listStudent = studentService.getAllStudent();
//        request.setAttribute("listStudent", listStudent);
//        request.getRequestDispatcher("/pages/student-list.jsp").forward(request, response);
//    }
//
//    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        try {
//            List<Faculty> faculties = facultyService.getAllFaculty();
//
//            // Deduplicate faculties by name
//            List<Faculty> uniqueFaculties = faculties.stream()
//                    .collect(Collectors.collectingAndThen(
//                            Collectors.toMap(Faculty::getName, f -> f, (f1, f2) -> f1, LinkedHashMap::new),
//                            m -> new ArrayList<>(m.values())
//                    ));
//
//            List<Subject> allSubjects = subjectService.getAllSubjects();
//
//            request.setAttribute("faculties", uniqueFaculties);
//            request.setAttribute("allSubjects", allSubjects);
//            request.setAttribute("professors", professorService.getAllProfessors());
//
//            request.getRequestDispatcher("/pages/student-form.jsp").forward(request, response);
//        } catch (SQLException e) {
//            e.printStackTrace();
//            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error loading form data");
//        }
//    }
//
//    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
//            throws SQLException, ServletException, IOException {
//        Long id = Long.parseLong(request.getParameter("id"));
//        Student existingStudent = studentService.getById(id);
//
//        if (existingStudent == null) {
//            response.sendError(HttpServletResponse.SC_NOT_FOUND, "Student not found");
//            return;
//        }
//
//        List<Faculty> faculties = facultyService.getAllFaculty();
//        List<Faculty> uniqueFaculties = faculties.stream()
//                .collect(Collectors.collectingAndThen(
//                        Collectors.toMap(Faculty::getName, f -> f, (f1, f2) -> f1, LinkedHashMap::new),
//                        m -> new ArrayList<>(m.values())
//                ));
//
//        List<Subject> allSubjects = subjectService.getAllSubjects();
//
//        request.setAttribute("student", existingStudent);
//        request.setAttribute("faculties", uniqueFaculties);
//        request.setAttribute("allSubjects", allSubjects);
//
//        request.getRequestDispatcher("/pages/student-form.jsp").forward(request, response);
//    }
//
//
//    private void insertStudent(HttpServletRequest request, HttpServletResponse response)
//            throws SQLException, IOException {
//        Student student = parseStudentFromRequest(request);
//        studentService.save(student);
//        response.sendRedirect(request.getContextPath() + "/student/list");
//    }
//
//    private void updateStudent(HttpServletRequest request, HttpServletResponse response)
//            throws SQLException, IOException {
//        Student student = parseStudentFromRequest(request);
//        student.setId(Long.parseLong(request.getParameter("id")));
//        studentService.update(student);
//        response.sendRedirect(request.getContextPath() + "/student/list");
//    }
//
//    private void deleteStudent(HttpServletRequest request, HttpServletResponse response)
//            throws SQLException, IOException {
//        Long id = Long.parseLong(request.getParameter("id"));
//        studentService.delete(id);
//        response.sendRedirect(request.getContextPath() + "/student/list");
//    }
//
//    private Student parseStudentFromRequest(HttpServletRequest request) {
//        String name = request.getParameter("name");
//        String surname = request.getParameter("surname");
//        String location = request.getParameter("location");
//        int indeks = Integer.parseInt(request.getParameter("indeks"));
//        long facultyId = Long.parseLong(request.getParameter("facultyId"));
//
//        String[] passedSubjectIds = request.getParameterValues("passedSubjects");
//        List<Subject> passedSubjects = new ArrayList<>();
//        if (passedSubjectIds != null) {
//            for (String idStr : passedSubjectIds) {
//                Subject subject = new Subject();
//                subject.setId(Long.parseLong(idStr));  // Use subject ID
//                passedSubjects.add(subject);
//            }
//        }
//
//        // facultyName can be null here, or fetched later if needed
//        return new Student(null, name, surname, location, indeks, null, facultyId, passedSubjects);
//    }
//    }
//


package controller;

import model.Faculty;
import model.Student;
import model.Subject;
import service.FacultyService;
import service.ProfessorService;
import service.StudentService;
import service.SubjectService;
import service.impl.FacultyServiceImpl;
import service.impl.ProfessorServiceImpl;
import service.impl.StudentServiceImpl;
import service.impl.SubjectServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.*;
import java.util.stream.Collectors;

public class StudentServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private final StudentService studentService = new StudentServiceImpl();
    private final FacultyService facultyService = new FacultyServiceImpl();
    private final ProfessorService professorService = new ProfessorServiceImpl();
    private final SubjectService subjectService = new SubjectServiceImpl();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = Optional.ofNullable(request.getPathInfo()).orElse("/list");

        try {
            switch (action) {
                case "/new":
                    showNewForm(request, response);
                    break;
                case "/insert":
                    insertStudent(request, response);
                    break;
                case "/delete":
                    deleteStudent(request, response);
                    break;
                case "/edit":
                    showEditForm(request, response);
                    break;
                case "/update":
                    updateStudent(request, response);
                    break;
                case "/list":
                default:
                    listStudent(request, response);
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException("Database error: " + ex.getMessage(), ex);
        }
    }

    private void listStudent(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        List<Student> listStudent = studentService.getAllStudent();
        request.setAttribute("listStudent", listStudent);
        request.getRequestDispatcher("/pages/student-list.jsp").forward(request, response);
    }

    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            List<Faculty> faculties = facultyService.getAllFaculty();

            // Deduplicate faculties by name
            List<Faculty> uniqueFaculties = faculties.stream()
                    .collect(Collectors.collectingAndThen(
                            Collectors.toMap(Faculty::getName, f -> f, (f1, f2) -> f1, LinkedHashMap::new),
                            m -> new ArrayList<>(m.values())
                    ));

            List<Subject> allSubjects = subjectService.getAllSubjects();

            Map<String, Subject> uniqueSubjectsMap = new LinkedHashMap<>();
            for (Subject s : allSubjects) {
                uniqueSubjectsMap.putIfAbsent(s.getName(), s);
            }
            List<Subject> uniqueSubjects = new ArrayList<>(uniqueSubjectsMap.values());

            request.setAttribute("allSubjects", uniqueSubjects);


            request.setAttribute("faculties", uniqueFaculties);
            request.setAttribute("professors", professorService.getAllProfessors()); // if needed in JSP

            request.getRequestDispatcher("/pages/student-form.jsp").forward(request, response);

        } catch (SQLException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error loading form data");
        }
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        Long id = Long.parseLong(request.getParameter("id"));
        Student existingStudent = studentService.getById(id);

        if (existingStudent == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND, "Student not found");
            return;
        }

        List<Faculty> faculties = facultyService.getAllFaculty();
        List<Faculty> uniqueFaculties = faculties.stream()
                .collect(Collectors.collectingAndThen(
                        Collectors.toMap(Faculty::getName, f -> f, (f1, f2) -> f1, LinkedHashMap::new),
                        m -> new ArrayList<>(m.values())
                ));

        List<Subject> allSubjects = subjectService.getAllSubjects();
        Map<String, Subject> uniqueSubjectsMap = new LinkedHashMap<>();
        for (Subject s : allSubjects) {
            uniqueSubjectsMap.putIfAbsent(s.getName(), s);
        }
        List<Subject> uniqueSubjects = new ArrayList<>(uniqueSubjectsMap.values());

        request.setAttribute("allSubjects", uniqueSubjects);

        request.setAttribute("student", existingStudent);
        request.setAttribute("faculties", uniqueFaculties);
        request.setAttribute("professors", professorService.getAllProfessors()); // Added here too!

        request.getRequestDispatcher("/pages/student-form.jsp").forward(request, response);
    }

    private void insertStudent(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        Student student = parseStudentFromRequest(request);
        studentService.save(student);
        response.sendRedirect(request.getContextPath() + "/student/list");
    }

    private void updateStudent(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        Student student = parseStudentFromRequest(request);
        student.setId(Long.parseLong(request.getParameter("id")));
        studentService.update(student);
        response.sendRedirect(request.getContextPath() + "/student/list");
    }

    private void deleteStudent(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        Long id = Long.parseLong(request.getParameter("id"));
        studentService.delete(id);
        response.sendRedirect(request.getContextPath() + "/student/list");
    }

    private Student parseStudentFromRequest(HttpServletRequest request) {
        String name = request.getParameter("name");
        String surname = request.getParameter("surname");
        String location = request.getParameter("location");
        int indeks = Integer.parseInt(request.getParameter("indeks"));
        long facultyId = Long.parseLong(request.getParameter("facultyId"));

        String[] passedSubjectIds = request.getParameterValues("passedSubjects");
        List<Subject> passedSubjects = new ArrayList<>();
        if (passedSubjectIds != null) {
            for (String idStr : passedSubjectIds) {
                Subject subject = new Subject();
                subject.setId(Long.parseLong(idStr));
                passedSubjects.add(subject);
            }
        }

        // You can fetch faculty name later if needed or leave null here
        return new Student(null, name, surname, location, indeks, null, facultyId, passedSubjects);
    }
}
