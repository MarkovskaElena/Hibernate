package controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Student;
import model.Subject;
import service.StudentService;
import service.SubjectService;
import service.impl.StudentServiceImpl;
import service.impl.SubjectServiceImpl;

public class SubjectServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private SubjectService subjectService;
    private StudentService studentService;

    public SubjectServlet() {
        this.subjectService = new SubjectServiceImpl();
        this.studentService = new StudentServiceImpl();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response); // Delegate POST to GET for simplicity
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getPathInfo();
        if (action == null) action = "/list";

        try {
            switch (action) {
                case "/new":
                    showNewForm(request, response);
                    break;
                case "/insert":
                    insertSubject(request, response);
                    break;
                case "/delete":
                    deleteSubject(request, response);
                    break;
                case "/edit":
                    showEditForm(request, response);
                    break;
                case "/update":
                    updateSubject(request, response);
                    break;
                case "/list":
                default:
                    listSubjects(request, response);
                    break;
            }
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }

    private void listSubjects(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        List<Subject> subjects = subjectService.getAllSubjects();
        request.setAttribute("listSubject", subjects);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/subject-list.jsp");
        dispatcher.forward(request, response);
    }

    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            List<Student> students = studentService.getAllStudent();
            Map<Long, Student> uniqueStudentsMap = new LinkedHashMap<>();
            for (Student s : students) {
                uniqueStudentsMap.putIfAbsent(s.getId(), s);
            }
            List<Student> uniqueStudents = new ArrayList<>(uniqueStudentsMap.values());

            request.setAttribute("students", uniqueStudents);
            RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/subject-form.jsp");
            dispatcher.forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error loading form data");
        }
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        Long id = Long.parseLong(request.getParameter("id"));
        Subject subject = subjectService.getById(id);

        if (subject == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND, "Subject not found");
            return;
        }

        List<Student> students = studentService.getAllStudent();
        Map<Long, Student> uniqueStudentsMap = new LinkedHashMap<>();
        for (Student s : students) {
            uniqueStudentsMap.putIfAbsent(s.getId(), s);
        }
        List<Student> uniqueStudents = new ArrayList<>(uniqueStudentsMap.values());

        request.setAttribute("subject", subject);
        request.setAttribute("students", uniqueStudents);


        RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/subject-form.jsp");
        dispatcher.forward(request, response);
    }

    private void insertSubject(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        String name = request.getParameter("name");
        String semester = request.getParameter("semester");
        String creditsStr = request.getParameter("credits");
        String studentIdStr = request.getParameter("studentId");
        String gradeStr = request.getParameter("grade");

        validateSubjectParams(name, semester, creditsStr, studentIdStr, gradeStr);

        int credits = Integer.parseInt(creditsStr);
        Long studentId = Long.parseLong(studentIdStr);
        int grade = Integer.parseInt(gradeStr);

        Subject subject = new Subject(null, name, semester, credits, studentId, grade);
        subjectService.save(subject);

        response.sendRedirect(request.getContextPath() + "/subject/list");
    }

    private void updateSubject(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        Long id = Long.parseLong(request.getParameter("id"));

        String name = request.getParameter("name");
        String semester = request.getParameter("semester");
        String creditsStr = request.getParameter("credits");
        String studentIdStr = request.getParameter("studentId");
        String gradeStr = request.getParameter("grade");

        validateSubjectParams(name, semester, creditsStr, studentIdStr, gradeStr);

        int credits = Integer.parseInt(creditsStr);
        Long studentId = Long.parseLong(studentIdStr);
        int grade = Integer.parseInt(gradeStr);

        Subject subject = new Subject(id, name, semester, credits, studentId, grade);
        subjectService.update(subject);

        response.sendRedirect(request.getContextPath() + "/subject/list");
    }

    private void deleteSubject(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        Long id = Long.parseLong(request.getParameter("id"));
        subjectService.delete(id);
        response.sendRedirect(request.getContextPath() + "/subject/list");
    }

    private void validateSubjectParams(String name, String semester, String creditsStr, String studentIdStr, String gradeStr) {
        if (name == null || name.trim().isEmpty())
            throw new IllegalArgumentException("Subject name is required");
        if (semester == null || semester.trim().isEmpty())
            throw new IllegalArgumentException("Semester is required");
        if (creditsStr == null || creditsStr.trim().isEmpty())
            throw new IllegalArgumentException("Credits are required");
        if (studentIdStr == null || studentIdStr.trim().isEmpty())
            throw new IllegalArgumentException("Student ID is required");
        if (gradeStr == null || gradeStr.trim().isEmpty())
            throw new IllegalArgumentException("Grade is required");
    }
}
