package controller;

import DAO.ProfessorDAO;
import DAO.impl.ProfessorDAOImpl;
import model.Professor;
import model.Subject;
import service.ProfessorService;
import service.SubjectService;
import service.impl.ProfessorServiceImpl;
import service.impl.SubjectServiceImpl;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/")
public class ProfessorServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private ProfessorService professorService;
    private SubjectService subjectService;

    public ProfessorServlet() {
        this.professorService = new ProfessorServiceImpl();
        this.subjectService = new SubjectServiceImpl();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getPathInfo();

        try {
            switch (action) {
                case "/insert":
                    insertProfessor(request, response);
                    break;
                case "/update":
                    updateProfessor(request, response);
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getPathInfo();
        if (action == null) {
            action = "/list";
        }

        try {
            switch (action) {
                case "/new":
                    showNewForm(request, response);
                    break;
                case "/insert":
                    insertProfessor(request, response);
                    break;
                case "/delete":
                    deleteProfessor(request, response);
                    break;
                case "/edit":
                    showEditForm(request, response);
                    break;
                case "/update":
                    updateProfessor(request, response);
                    break;
                case "/list":
                    listProfessor(request, response);
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }

    private void listProfessor(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        List<Professor> listProfessor = professorService.getAllFaculty();
        request.setAttribute("listProfessor", listProfessor);
        RequestDispatcher dispatcher = request.getRequestDispatcher("pages/professor-list.jsp");
        dispatcher.forward(request, response);
    }

    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        List<Subject> subjects = subjectService.getAllFaculty();
        request.setAttribute("subjects", subjects);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/professor-form.jsp");
        dispatcher.forward(request, response);
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        Long id = Long.parseLong(request.getParameter("id"));
        Professor existingProfessor = professorService.getById(id);

        if (existingProfessor == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND, "Professor not found");
            return;
        }

        List<Subject> subjects = subjectService.getAllFaculty();
        request.setAttribute("subjects", subjects);
        request.setAttribute("professor", existingProfessor);

        RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/professor-form.jsp");
        dispatcher.forward(request, response);
    }

    private void insertProfessor(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        String name = request.getParameter("name");
        String surname = request.getParameter("surname");
        Integer age = Integer.parseInt(request.getParameter("age"));
        String primarySubject = request.getParameter("primarySubject");
        String secondarySubject = request.getParameter("secondarySubject");

        Professor professor = new Professor(null, name, surname, age, primarySubject, secondarySubject);
        professorService.save(professor);
        response.sendRedirect(request.getContextPath() + "/list");
    }

    private void updateProfessor(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        Long id = Long.parseLong(request.getParameter("id"));
        String name = request.getParameter("name");
        String surname = request.getParameter("surname");
        Integer age = Integer.parseInt(request.getParameter("age"));
        String primarySubject = request.getParameter("primarySubject");
        String secondarySubject = request.getParameter("secondarySubject");

        Professor professor = new Professor(id, name, surname, age, primarySubject, secondarySubject);
        professorService.update(professor);
        response.sendRedirect(request.getContextPath() + "/list");
    }

    private void deleteProfessor(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        Long id = Long.parseLong(request.getParameter("id"));
        professorService.delete(id);
        response.sendRedirect(request.getContextPath() + "/list");
    }
}
