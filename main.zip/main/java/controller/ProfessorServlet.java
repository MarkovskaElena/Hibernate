package controller;

import DAO.ProfessorDAO;
import DAO.impl.ProfessorDAOImpl;
import model.Professor;
import model.Subject;
import service.ProfessorService;
import service.SubjectService;
import service.impl.ProfessorServiceImpl;
import service.impl.SubjectServiceImpl;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

public class ProfessorServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private ProfessorService professorService;
    private SubjectService subjectService;

    public ProfessorServlet() {
        this.professorService = new ProfessorServiceImpl();
        this.subjectService = new SubjectServiceImpl();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getPathInfo();
        if (action == null || action.equals("/")) {
            action = "/list";
        }

        System.out.println("Action: " + action);

        try {
            switch (action) {
                case "/new":
                    showNewForm(request, response);
                    break;
                case "/insert":
                    insertProfessor(request, response);
                    break;
                case "/delete":
                    deleteProfessor(request, response);
                    break;
                case "/edit":
                    showEditForm(request, response);
                    break;
                case "/update":
                    updateProfessor(request, response);
                    break;
                case "/list":
                    listProfessor(request, response);
                    break;
                default:
                    response.sendError(HttpServletResponse.SC_NOT_FOUND);
                    break;
            }
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }

    private void listProfessor(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        List<Professor> professors = professorService.getAllProfessors();
        System.out.println("Professors in listProfessor: " + professors.size());
        request.setAttribute("listProfessor", professors);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/professor-list.jsp");
        dispatcher.forward(request, response);
    }

    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        List<Subject> subjects = subjectService.getAllSubjects();
        request.setAttribute("subjects", subjects);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/professor-form.jsp");
        dispatcher.forward(request, response);
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        Long id = Long.parseLong(request.getParameter("id"));
        Professor existingProfessor = professorService.getById(id);
        if (existingProfessor == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND, "Professor not found");
            return;
        }

        List<Subject> subjects = subjectService.getAllSubjects();
        request.setAttribute("professor", existingProfessor);
        request.setAttribute("subjects", subjects);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/professor-form.jsp");
        dispatcher.forward(request, response);
    }

    private void insertProfessor(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        String name = request.getParameter("name");
        String surname = request.getParameter("surname");
        String ageStr = request.getParameter("age");
        String primarySubject = request.getParameter("primarySubject");
        String secondarySubject = request.getParameter("secondarySubject");

        if (name == null || name.trim().isEmpty() ||
                surname == null || surname.trim().isEmpty() ||
                ageStr == null || ageStr.trim().isEmpty() ||
                primarySubject == null || primarySubject.trim().isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "All required fields must be filled");
            return;
        }

        Integer age = Integer.parseInt(ageStr);
        Professor professor = new Professor(null, name, surname, age, primarySubject, secondarySubject);
        professorService.save(professor);

        response.sendRedirect(request.getContextPath() + "/professor/list");
    }

    private void updateProfessor(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        Long id = Long.parseLong(request.getParameter("id"));
        String name = request.getParameter("name");
        String surname = request.getParameter("surname");
        String ageStr = request.getParameter("age");
        String primarySubject = request.getParameter("primarySubject");
        String secondarySubject = request.getParameter("secondarySubject");

        if (name == null || name.trim().isEmpty() ||
                surname == null || surname.trim().isEmpty() ||
                ageStr == null || ageStr.trim().isEmpty() ||
                primarySubject == null || primarySubject.trim().isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "All required fields must be filled");
            return;
        }

        Integer age = Integer.parseInt(ageStr);
        Professor professor = new Professor(id, name, surname, age, primarySubject, secondarySubject);
        professorService.update(professor);

        response.sendRedirect(request.getContextPath() + "/professor/list");
    }

    private void deleteProfessor(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        Long id = Long.parseLong(request.getParameter("id"));
        professorService.delete(id);
        response.sendRedirect(request.getContextPath() + "/professor/list");
    }
}
