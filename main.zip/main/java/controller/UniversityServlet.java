package controller;

import model.University;
import service.UniversityService;
import service.impl.UniversityServiceImpl;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

public class UniversityServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private UniversityService universityService;

    public UniversityServlet() {
        this.universityService = new UniversityServiceImpl();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getPathInfo();
        if (action == null) {
            action = "/list";
        }

        try {
            switch (action) {
                case "/new":
                    showNewForm(request, response);
                    break;
                case "/insert":
                    insertUniversity(request, response);
                    break;
                case "/delete":
                    deleteUniversity(request, response);
                    break;
                case "/edit":
                    showEditForm(request, response);
                    break;
                case "/update":
                    updateUniversity(request, response);
                    break;
                case "/list":
                default:
                    listUniversities(request, response);
                    break;
            }
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }

    private void listUniversities(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        List<University> universities = universityService.getAllUniversities();
        request.setAttribute("universities", universities);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/university-list.jsp");
        dispatcher.forward(request, response);
    }

    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/university-form.jsp");
        dispatcher.forward(request, response);
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        Long id = Long.parseLong(request.getParameter("id"));
        University university = universityService.getById(id);
        if (university == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND, "University not found");
            return;
        }
        request.setAttribute("university", university);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/university-form.jsp");
        dispatcher.forward(request, response);
    }

    private void insertUniversity(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        String name = request.getParameter("name");
        String location = request.getParameter("location");
        String isPrivateParam = request.getParameter("isPrivate");
        Boolean isPrivate = isPrivateParam != null && Boolean.parseBoolean(isPrivateParam);

        if (name == null || name.trim().isEmpty() || location == null || location.trim().isEmpty()) {
            request.setAttribute("errorMessage", "Name and location are required.");
            request.getRequestDispatcher("/pages/university-form.jsp").forward(request, response);
            return;
        }

        University university = new University(null, name, location, isPrivate);

        universityService.save(university);
        response.sendRedirect(request.getContextPath() + "/university/list");
    }

    private void updateUniversity(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        Long id = Long.parseLong(request.getParameter("id"));
        String name = request.getParameter("name");
        String location = request.getParameter("location");
        Boolean isPrivate = Boolean.parseBoolean(request.getParameter("isPrivate"));

        University university = new University(id, name, location, isPrivate);
        universityService.update(university);
        response.sendRedirect(request.getContextPath() + "/university/list");
    }

    private void deleteUniversity(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        Long id = Long.parseLong(request.getParameter("id"));
        universityService.delete(id);
        response.sendRedirect(request.getContextPath() + "/university/list");
    }
}
