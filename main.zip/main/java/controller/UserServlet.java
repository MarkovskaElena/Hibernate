package controller;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class UserServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //response.setContentType("text/html");

        RequestDispatcher rd = request.getRequestDispatcher("pages/users.jsp");
        rd.forward(request, response);

        //response.sendRedirect(request.getContextPath() + "/users.jsp");
    }

    public UserServlet(){

    }
}
