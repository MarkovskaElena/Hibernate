//package controller;
//
//import java.io.IOException;
//import java.sql.SQLException;
//import java.util.*;
//import javax.servlet.RequestDispatcher;
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//import DAO.FacultyDAO;
//import DAO.impl.FacultyDAOImpl;
//import model.Faculty;
//import model.University;
//import service.FacultyService;
//import service.UniversityService;
//import service.impl.FacultyServiceImpl;
//import service.impl.UniversityServiceImpl;
//
//@WebServlet("/")
//public class FacultyServlet extends HttpServlet {
//    private static final long serialVersionUID = 1L;
//
//    private FacultyService facultyService;
//    private UniversityService universityService;
//    private FacultyDAO facultyDAO;
//
//    public FacultyServlet() {
//        this.facultyService = new FacultyServiceImpl();
//        this.universityService = new UniversityServiceImpl();
//        this.facultyDAO = new FacultyDAOImpl();
//    }
//
//    protected void doPost(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        doGet(request, response);  // Повикува doGet за сите POST барања
//    }
//
//    protected void doGet(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        String action = request.getServletPath();
//        System.out.println("Action: " + action);
//
//        try {
//            switch (action) {
//                case "/new":
//                    showNewForm(request, response);
//                    break;
//                case "/insert":
//                    insertFaculty(request, response);
//                    break;
//                case "/delete":
//                    deleteFaculty(request, response);
//                    break;
//                case "/edit":
//                    showEditForm(request, response);
//                    break;
//                case "/update":
//                    updateFaculty(request, response);
//                    break;
//                case "/list":
//                case "/":
//                    listFaculty(request, response);
//                    break;
//                default:
//                    response.sendError(HttpServletResponse.SC_NOT_FOUND);
//                    break;
//            }
//        } catch (SQLException e) {
//            throw new ServletException(e);
//        }
//    }
//
//    private void listFaculty(HttpServletRequest request, HttpServletResponse response)
//            throws SQLException, IOException, ServletException {
//        List<Faculty> listFaculty = facultyDAO.getAll();
//        request.setAttribute("listFaculty", listFaculty);
//        RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/faculty-list.jsp");
//        dispatcher.forward(request, response);
//    }
//
//    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException, SQLException {
//        List<University> universities = universityService.getAllUniversities();
//        request.setAttribute("universities", universities);
//        RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/faculty-form.jsp");
//        dispatcher.forward(request, response);
//    }
//
//    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
//            throws SQLException, ServletException, IOException {
//        Long id = Long.parseLong(request.getParameter("id"));
//        Faculty existingFaculty = facultyService.getById(id);
//        if (existingFaculty == null) {
//            response.sendError(HttpServletResponse.SC_NOT_FOUND, "Faculty not found");
//            return;
//        }
//        List<University> universities = universityService.getAllUniversities();
//        request.setAttribute("faculty", existingFaculty);
//        request.setAttribute("universities", universities);
//        RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/faculty-form.jsp");
//        dispatcher.forward(request, response);
//    }
//
//    private void insertFaculty(HttpServletRequest request, HttpServletResponse response)
//            throws SQLException, IOException {
//        String name = request.getParameter("name");
//        String location = request.getParameter("location");
//        String studyField = request.getParameter("studyField");
//        String universityIdStr = request.getParameter("university_id");
//
//        if (name == null || name.trim().isEmpty() ||
//                location == null || location.trim().isEmpty() ||
//                studyField == null || studyField.trim().isEmpty() ||
//                universityIdStr == null || universityIdStr.trim().isEmpty()) {
//            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "All fields are required");
//            return;
//        }
//
//        long universityId = Long.parseLong(universityIdStr);
//
//        Faculty faculty = new Faculty(null, name, location, studyField, universityId);
//        facultyService.save(faculty);
//
//        response.sendRedirect("list");
//    }
//
//    private void updateFaculty(HttpServletRequest request, HttpServletResponse response)
//            throws SQLException, IOException {
//        Long id = Long.parseLong(request.getParameter("id"));
//        String name = request.getParameter("name");
//        String location = request.getParameter("location");
//        String studyField = request.getParameter("studyField");
//        String universityIdStr = request.getParameter("university_id");
//
//        if (name == null || name.trim().isEmpty() ||
//                location == null || location.trim().isEmpty() ||
//                studyField == null || studyField.trim().isEmpty() ||
//                universityIdStr == null || universityIdStr.trim().isEmpty()) {
//            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "All fields are required");
//            return;
//        }
//
//        Long universityId = Long.parseLong(universityIdStr);
//        Faculty faculty = new Faculty(id, name, location, studyField, universityId);
//        facultyService.update(faculty);
//
//        response.sendRedirect("list");
//    }
//
//    private void deleteFaculty(HttpServletRequest request, HttpServletResponse response)
//            throws SQLException, IOException {
//        Long id = Long.parseLong(request.getParameter("id"));
//        facultyService.delete(id);
//        response.sendRedirect("list");
//    }
//}


package controller;

import DAO.FacultyDAO;
import DAO.impl.FacultyDAOImpl;
import model.Faculty;
import model.University;
import service.FacultyService;
import service.UniversityService;
import service.impl.FacultyServiceImpl;
import service.impl.UniversityServiceImpl;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

//@WebServlet("/faculty/*")
public class FacultyServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private FacultyService facultyService;
    private UniversityService universityService;
    private FacultyDAO facultyDAO;

    public FacultyServlet() {
        this.facultyService = new FacultyServiceImpl();
        this.universityService = new UniversityServiceImpl();
        this.facultyDAO = new FacultyDAOImpl();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Delegate POST requests to doGet for simplicity
        doGet(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getPathInfo();  // e.g., /list, /new, /edit
        if (action == null || action.equals("/")) {
            action = "/list";  // default action
        }

        try {
            switch (action) {
                case "/new":
                    showNewForm(request, response);
                    break;
                case "/insert":
                    insertFaculty(request, response);
                    break;
                case "/delete":
                    deleteFaculty(request, response);
                    break;
                case "/edit":
                    showEditForm(request, response);
                    break;
                case "/update":
                    updateFaculty(request, response);
                    break;
                case "/list":
                    listFaculty(request, response);
                    break;
                default:
                    response.sendError(HttpServletResponse.SC_NOT_FOUND);
                    break;
            }
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }

    private void listFaculty(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        List<Faculty> listFaculty = facultyDAO.getAll();
        request.setAttribute("listFaculty", listFaculty);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/faculty-list.jsp");
        dispatcher.forward(request, response);
    }

    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        List<University> universities = universityService.getAllUniversities();
        request.setAttribute("universities", universities);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/faculty-form.jsp");
        dispatcher.forward(request, response);
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        Long id = Long.parseLong(request.getParameter("id"));
        Faculty existingFaculty = facultyService.getById(id);
        if (existingFaculty == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND, "Faculty not found");
            return;
        }
        List<University> universities = universityService.getAllUniversities();
        request.setAttribute("faculty", existingFaculty);
        request.setAttribute("universities", universities);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/faculty-form.jsp");
        dispatcher.forward(request, response);
    }

    private void insertFaculty(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        String name = request.getParameter("name");
        String location = request.getParameter("location");
        String studyField = request.getParameter("studyField");
        String universityIdStr = request.getParameter("university_id");

        if (name == null || name.trim().isEmpty() ||
                location == null || location.trim().isEmpty() ||
                studyField == null || studyField.trim().isEmpty() ||
                universityIdStr == null || universityIdStr.trim().isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "All fields are required");
            return;
        }

        long universityId = Long.parseLong(universityIdStr);
        Faculty faculty = new Faculty(null, name, location, studyField, universityId);
        facultyService.save(faculty);

        response.sendRedirect(request.getContextPath() + "/faculty/list");
    }

    private void updateFaculty(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        Long id = Long.parseLong(request.getParameter("id"));
        String name = request.getParameter("name");
        String location = request.getParameter("location");
        String studyField = request.getParameter("studyField");
        String universityIdStr = request.getParameter("university_id");

        if (name == null || name.trim().isEmpty() ||
                location == null || location.trim().isEmpty() ||
                studyField == null || studyField.trim().isEmpty() ||
                universityIdStr == null || universityIdStr.trim().isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "All fields are required");
            return;
        }

        Long universityId = Long.parseLong(universityIdStr);
        Faculty faculty = new Faculty(id, name, location, studyField, universityId);
        facultyService.update(faculty);

        response.sendRedirect(request.getContextPath() + "/faculty/list");
    }

    private void deleteFaculty(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        Long id = Long.parseLong(request.getParameter("id"));
        facultyService.delete(id);
        response.sendRedirect(request.getContextPath() + "/faculty/list");
    }
}
