package controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import DAO.FacultyDAO;
import model.Faculty;
import DAO.impl.FacultyDAOImpl;
import model.University;
import service.FacultyService;
import service.UniversityService;
import service.impl.FacultyServiceImpl;
import service.impl.UniversityServiceImpl;


@WebServlet("/")
public class FacultyServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private FacultyService facultyService;
    private UniversityService universityService;
    private FacultyDAO facultyDAO;

    public FacultyServlet() {
        this.facultyService = new FacultyServiceImpl();
        this.universityService = new UniversityServiceImpl();
        this.facultyDAO = new FacultyDAOImpl();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //doGet(request, response);
        //response.sendRedirect("faculty-form.jsp");
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getPathInfo();
        if (action == null) {
            action = "/list";
        }

        try {
            switch (action) {
                case "/new":
                    showNewForm(request, response);
                    break;
                case "/insert":
                    insertFaculty(request, response);
                    break;
                case "/delete":
                    deleteFaculty(request, response);
                    break;
                case "/edit":
                    showEditForm(request, response);
                    break;
                case "/update":
                    updateFaculty(request, response);
                    break;
                case "/list":
                    listFaculty(request, response);
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }

    private void listFaculty(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        List<Faculty> listFaculty = facultyDAO.getAll();

        request.setAttribute("listFaculty", listFaculty);
        RequestDispatcher dispatcher = request.getRequestDispatcher("pages/faculty-list.jsp");
        dispatcher.forward(request, response);
    }


    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            List<University> universities = universityService.getAllUniversities();
            Set<String> universityNames = new HashSet<>();
            List<University> uniqueUniversities = new ArrayList<>();
            Collections.sort(universities, Comparator.comparing(University::getName));


            for (University university : universities) {
                if (universityNames.add(university.getName())) {
                    uniqueUniversities.add(university);
                }
                System.out.println("University ID: " + university.getId() + " Name: " + university.getName());

            }
            request.setAttribute("universities", uniqueUniversities);
            RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/faculty-form.jsp");
            dispatcher.forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error fetching universities");
        }
    }


    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        Long id = Long.parseLong(request.getParameter("id"));

        Faculty existingFaculty = facultyService.getById(id);

        if (existingFaculty == null) {
            System.out.println("No faculty found with ID: " + id);
            response.sendError(HttpServletResponse.SC_NOT_FOUND, "Faculty not found");
            return;
        }

        List<University> universities = universityService.getAllUniversities();

        Set<String> universityNames = new HashSet<>();
        List<University> uniqueUniversities = new ArrayList<>();
        Collections.sort(universities, Comparator.comparing(University::getName));

        for (University university : universities) {
            if (universityNames.add(university.getName())) {
                uniqueUniversities.add(university);
            }
        }

        request.setAttribute("faculty", existingFaculty);
        request.setAttribute("universities", uniqueUniversities);

        RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/faculty-form.jsp");
        dispatcher.forward(request, response);
    }



    private void insertFaculty(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        String name = request.getParameter("name");
        String location = request.getParameter("location");
        String studyField = request.getParameter("studyField");
        String universityIdStr = request.getParameter("university_id");

        System.out.println("Received university_id: " + universityIdStr);

        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Faculty name is required");
        }
        if (location == null || location.trim().isEmpty()) {
            throw new IllegalArgumentException("Faculty location is required");
        }
        if (studyField == null || studyField.trim().isEmpty()) {
            throw new IllegalArgumentException("Study field is required");
        }

        if (universityIdStr == null || universityIdStr.isEmpty()) {
            throw new IllegalArgumentException("University ID is missing or invalid");
        }

        long universityId = Long.parseLong(universityIdStr);
        System.out.println("Received parameters: name=" + name + ", location=" + location + ", studyField=" + studyField + ", university_id=" + universityId);  // Debugging

        Faculty faculty = new Faculty(null, name, location, studyField, universityId);
        facultyService.save(faculty);
        response.sendRedirect(request.getContextPath() + "/list");
    }


//    private void insertFaculty(HttpServletRequest request, HttpServletResponse response)
//            throws SQLException, IOException {
//        String name = request.getParameter("name");
//        String location = request.getParameter("location");
//        String studyField = request.getParameter("studyField");
//        //Long universityId = Long.parseLong(request.getParameter("university_id"));
//        String universityIdStr = request.getParameter("university_id");
//        System.out.println("Received university_id: " + universityIdStr);
//
//        if (universityIdStr == null || universityIdStr.isEmpty()) {
//            throw new IllegalArgumentException("University ID is missing or invalid");
//        }
//
//        long universityId = Long.parseLong(universityIdStr);
//
//        System.out.println("Received parameters: name=" + name + ", location=" + location + ", studyField=" + studyField + ", university_id=" + universityId);
//
//        Faculty faculty = new Faculty(null, name, location, studyField, universityId);
//        facultyService.save(faculty);
//        response.sendRedirect(request.getContextPath() + "/list");
//    }

    private void updateFaculty(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        String idStr = request.getParameter("id");
        Long id = Long.parseLong(idStr);
        String name = request.getParameter("name");
        String location = request.getParameter("location");
        String studyField = request.getParameter("studyField");
        String universityIdStr = request.getParameter("university_id");
        System.out.println("Received university_id: " + universityIdStr);

        if (universityIdStr == null || universityIdStr.isEmpty()) {
            System.out.println("Error: university_id is null or empty");
            throw new IllegalArgumentException("University ID is missing or invalid");
        }

        Long universityId = Long.parseLong(universityIdStr);
        Faculty faculty = new Faculty(id, name, location, studyField, universityId);
        facultyService.update(faculty);
        response.sendRedirect(request.getContextPath() + "/list");
    }

    private void deleteFaculty(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        Long id = Long.parseLong(request.getParameter("id"));
        facultyService.delete(id);

        List<Faculty> listFaculty = facultyService.getAllFaculty();
        request.getSession().setAttribute("listFaculty", listFaculty);
        response.sendRedirect(request.getContextPath() + "/list");
    }

}