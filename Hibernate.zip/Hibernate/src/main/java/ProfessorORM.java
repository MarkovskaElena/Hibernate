import com.myapp.entities.HibernateUtil;
import com.myapp.entities.Professor;
import org.hibernate.query.Query;
import java.util.List;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.EntityManagerFactory;


public class ProfessorORM {
        public static void main(String[] args) {
            InsertProfessorORM insertProfessorORM = new InsertProfessorORM();
            SelectProfessorORM selectProfessorORM = new SelectProfessorORM();
            UpdateProfessorORM updateProfessorORM = new UpdateProfessorORM();
            DeleteProfessorORM deleteProfessorORM = new DeleteProfessorORM();

            try {

                System.out.println("\nAll IDs:");
                List<Integer> allIds = selectProfessorORM.getAllIds();
                System.out.println(allIds);

                System.out.println("\nGet professor by ID 1:");
                selectProfessorORM.selectById(1);

                insertProfessorORM.insertRecord("Dr. Jane", "Doe", 45, "Physics", "Mathematics");
                System.out.println("\nAfter inserting a new record:");
                selectProfessorORM.selectAllRecords();

                updateProfessorORM.updateRecord(1, "Dr. Jane", "First", 46, "Physics", "Mathematics");

                System.out.println("\nGet professor by updated ID 1:");
                selectProfessorORM.selectById(1);

                deleteProfessorORM.deleteRecord(12);  // Adjust the ID based on your data
                System.out.println("\nAfter deleting record with ID 12:");
                selectProfessorORM.selectAllRecords();

                System.out.println("All IDs after delete:");
                allIds = selectProfessorORM.getAllIds();
                System.out.println(allIds);

            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                HibernateUtil.shutdown();
            }
        }
    }

 class InsertProfessorORM {
    public void insertRecord(String name, String surname, int age, String primarySubject, String secondarySubject) {
        EntityManagerFactory emf = HibernateUtil.getEntityManagerFactory();
        EntityManager em = emf.createEntityManager();
        EntityTransaction transaction = null;

        try {
            transaction = em.getTransaction();
            transaction.begin();

            Professor professor = new Professor();
            professor.setName(name);
            professor.setSurname(surname);
            professor.setAge(age);
            professor.setPrimarySubject(primarySubject);
            professor.setSecondarySubject(secondarySubject);

            em.persist(professor);

            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            em.close();
        }
    }
}


 class SelectProfessorORM {

    public void selectAllRecords() {
        EntityManagerFactory emf = HibernateUtil.getEntityManagerFactory();
        EntityManager em = emf.createEntityManager();

        try {
            List<Professor> professors = em.createQuery("FROM Professor", Professor.class).getResultList();
            for (Professor professor : professors) {
                System.out.println(professor.getId() + ", " + professor.getName() + ", " + professor.getSurname() + ", " + professor.getAge() + ", " + professor.getPrimarySubject() + ", " + professor.getSecondarySubject());
            }
        } finally {
            em.close();
        }
    }

    public void selectById(int id) {
        EntityManagerFactory emf = HibernateUtil.getEntityManagerFactory();
        EntityManager em = emf.createEntityManager();

        try {
            Professor professor = em.find(Professor.class, id);
            if (professor != null) {
                System.out.println(professor.getId() + ", " + professor.getName() + ", " + professor.getSurname() + ", " + professor.getAge() + ", " + professor.getPrimarySubject() + ", " + professor.getSecondarySubject());
            } else {
                System.out.println("No professor found with ID " + id);
            }
        } finally {
            em.close();
        }
    }

    public List<Integer> getAllIds() {
        EntityManagerFactory emf = HibernateUtil.getEntityManagerFactory();
        EntityManager em = emf.createEntityManager();

        try {
            Query query = (Query) em.createQuery("SELECT p.id FROM Professor p");
            return query.getResultList();
        } finally {
            em.close();
        }
    }
}


 class UpdateProfessorORM {
    public void updateRecord(int id, String name, String surname, int age, String primarySubject, String secondarySubject) {
        EntityManagerFactory emf = HibernateUtil.getEntityManagerFactory();
        EntityManager em = emf.createEntityManager();
        EntityTransaction transaction = null;

        try {
            transaction = em.getTransaction();
            transaction.begin();

            Professor professor = em.find(Professor.class, id);
            if (professor != null) {
                professor.setName(name);
                professor.setSurname(surname);
                professor.setAge(age);
                professor.setPrimarySubject(primarySubject);
                professor.setSecondarySubject(secondarySubject);

                em.merge(professor);
            } else {
                System.out.println("Professor with ID " + id + " does not exist.");
            }

            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            em.close();
        }
    }
}

 class DeleteProfessorORM {
    public void deleteRecord(int id) {
        EntityManagerFactory emf = HibernateUtil.getEntityManagerFactory();
        EntityManager em = emf.createEntityManager();
        EntityTransaction transaction = null;

        try {
            transaction = em.getTransaction();
            transaction.begin();

            Professor professor = em.find(Professor.class, id);
            if (professor != null) {
                em.remove(professor);
            } else {
                System.out.println("Professor with ID " + id + " does not exist.");
            }

            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            em.close();
        }
    }
}

