import com.myapp.entities.HibernateUtil;
import com.myapp.entities.University;
import org.hibernate.query.Query;
import java.util.List;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.EntityManagerFactory;

public class UniversityORM {
    public static void main(String[] args) {
        InsertUniversityORM insertUniversityORM = new InsertUniversityORM();
        SelectUniversityORM selectUniversityORM = new SelectUniversityORM();
        UpdateUniversityORM updateUniversityORM = new UpdateUniversityORM();
        DeleteUniversityORM deleteUniversityORM = new DeleteUniversityORM();

        try {

            System.out.println("\nAll IDs:");
            List<Integer> allIds = selectUniversityORM.getAllIds();
            System.out.println(allIds);

            System.out.println("\nGet university by ID 1:");
            selectUniversityORM.selectById(1);

            System.out.println("\nGet university by updated ID 16:");
            selectUniversityORM.selectById(16);

            insertUniversityORM.insertRecord("University of Michigan, Ann Arbor", "Ann Arbor, MI", 1);
            System.out.println("\nAfter inserting a new record:");
            selectUniversityORM.selectAllRecords();

            updateUniversityORM.updateRecord(4, "Berkeley, CA", "Skopje, MK", 1);

            System.out.println("\nGet university by updated ID 5:");
            selectUniversityORM.selectById(5);

            deleteUniversityORM.deleteRecord(12);  // Adjust the ID based on your data
            System.out.println("\nAfter deleting record with ID 12:");
            selectUniversityORM.selectAllRecords();

            System.out.println("All IDs after delete:");
            allIds = selectUniversityORM.getAllIds();
            System.out.println(allIds);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            HibernateUtil.shutdown();
        }
    }
}

class InsertUniversityORM {
    public void insertRecord(String name, String location, int isPrivate) {
        EntityManagerFactory emf = HibernateUtil.getEntityManagerFactory();
        EntityManager em = emf.createEntityManager();
        EntityTransaction transaction = null;

        try {
            transaction = em.getTransaction();
            transaction.begin();

            University university = new University();
            university.setName(name);
            university.setLocation(location);
            university.setIsPrivate((byte) isPrivate);

            em.persist(university);

            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            em.close();
        }
    }
}


class SelectUniversityORM {

    public void selectAllRecords() {
        EntityManagerFactory emf = HibernateUtil.getEntityManagerFactory();
        EntityManager em = emf.createEntityManager();

        try {
            List<University> universitys = em.createQuery("FROM University", University.class).getResultList();
            for (University university : universitys) {
                System.out.println(university.getId() + ", " + university.getName() + ", " + university.getLocation() + ", " + university.getIsPrivate());
            }
        } finally {
            em.close();
        }
    }

    public void selectById(int id) {
        EntityManagerFactory emf = HibernateUtil.getEntityManagerFactory();
        EntityManager em = emf.createEntityManager();

        try {
            University university = em.find(University.class, id);
            if (university != null) {
                System.out.println(university.getId() + ", " + university.getName() + ", " + university.getLocation() + ", " + university.getIsPrivate());
            } else {
                System.out.println("No university found with ID " + id);
            }
        } finally {
            em.close();
        }
    }

    public List<Integer> getAllIds() {
        EntityManagerFactory emf = HibernateUtil.getEntityManagerFactory();
        EntityManager em = emf.createEntityManager();

        try {
            Query query = (Query) em.createQuery("SELECT u.id FROM University u");
            return query.getResultList();
        } finally {
            em.close();
        }
    }
}


class UpdateUniversityORM {
    public void updateRecord(int id, String name, String location, int isPrivate) {
        EntityManagerFactory emf = HibernateUtil.getEntityManagerFactory();
        EntityManager em = emf.createEntityManager();
        EntityTransaction transaction = null;

        try {
            transaction = em.getTransaction();
            transaction.begin();

            University university = em.find(University.class, id);
            if (university != null) {
                university.setName(name);
                university.setName(name);
                university.setLocation(location);
                university.setIsPrivate((byte) isPrivate);

                em.merge(university);
            } else {
                System.out.println("university with ID " + id + " does not exist.");
            }

            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            em.close();
        }
    }
}

class DeleteUniversityORM {
    public void deleteRecord(int id) {
        EntityManagerFactory emf = HibernateUtil.getEntityManagerFactory();
        EntityManager em = emf.createEntityManager();
        EntityTransaction transaction = null;

        try {
            transaction = em.getTransaction();
            transaction.begin();

            University university = em.find(University.class, id);
            if (university != null) {
                em.remove(university);
            } else {
                System.out.println("university with ID " + id + " does not exist.");
            }

            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            em.close();
        }
    }
}

