import com.myapp.entities.Faculty;

public class Main {
    public static void main(String[] args) {
        Faculty faculty = new Faculty();
        faculty.setId(1);
        faculty.setName("Name");

    }
}
