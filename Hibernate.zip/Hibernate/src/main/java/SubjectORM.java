import com.myapp.entities.HibernateUtil;
import com.myapp.entities.Subject;
import org.hibernate.query.Query;
import java.util.List;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.EntityManagerFactory;
public class SubjectORM {
    public static void main(String[] args) {
        InsertSubjectORM insertSubjectORM = new InsertSubjectORM();
        SelectSubjectORM selectSubjectORM = new SelectSubjectORM();
        UpdateSubjectORM updateSubjectORM = new UpdateSubjectORM();
        DeleteSubjectORM deleteSubjectORM = new DeleteSubjectORM();

        try {

            System.out.println("\nAll IDs:");
            List<Integer> allIds = selectSubjectORM.getAllIds();
            System.out.println(allIds);

            System.out.println("\nGet subject by ID 1:");
            selectSubjectORM.selectById(1);

            System.out.println("\nGet subject by ID 16:");
            selectSubjectORM.selectById(16);

            insertSubjectORM.insertRecord("Science", "Spring", 7);
            System.out.println("\nAfter inserting a new record:");
            selectSubjectORM.selectAllRecords();

            updateSubjectORM.updateRecord(4, "Science", "Fall", 8);

            System.out.println("\nGet Subject by updated ID 27:");
            selectSubjectORM.selectById(27);

            deleteSubjectORM.deleteRecord(12);  // Adjust the ID based on your data
            System.out.println("\nAfter deleting record with ID 12:");
            selectSubjectORM.selectAllRecords();

            System.out.println("All IDs after delete:");
            allIds = selectSubjectORM.getAllIds();
            System.out.println(allIds);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            HibernateUtil.shutdown();
        }
    }
}

class InsertSubjectORM {
    public void insertRecord(String name, String semester, int credits) {
        EntityManagerFactory emf = HibernateUtil.getEntityManagerFactory();
        EntityManager em = emf.createEntityManager();
        EntityTransaction transaction = null;

        try {
            transaction = em.getTransaction();
            transaction.begin();

            Subject subject = new Subject();
            subject.setName(name);
            subject.setSemester(semester);
            subject.setCredits(credits);

            em.persist(subject);

            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            em.close();
        }
    }
}


class SelectSubjectORM {

    public void selectAllRecords() {
        EntityManagerFactory emf = HibernateUtil.getEntityManagerFactory();
        EntityManager em = emf.createEntityManager();

        try {
            List<Subject> subjects = em.createQuery("FROM Subject", Subject.class).getResultList();
            for (Subject subject : subjects) {
                System.out.println(subject.getId() + ", " + subject.getName() + ", " + subject.getSemester() + ", " + subject.getCredits());
            }
        } finally {
            em.close();
        }
    }

    public void selectById(int id) {
        EntityManagerFactory emf = HibernateUtil.getEntityManagerFactory();
        EntityManager em = emf.createEntityManager();

        try {
            Subject subject = em.find(Subject.class, id);
            if (subject != null) {
                System.out.println(subject.getId() + ", " + subject.getName() + ", " + subject.getSemester() + ", " + subject.getCredits());
            } else {
                System.out.println("No subject found with ID " + id);
            }
        } finally {
            em.close();
        }
    }

    public List<Integer> getAllIds() {
        EntityManagerFactory emf = HibernateUtil.getEntityManagerFactory();
        EntityManager em = emf.createEntityManager();

        try {
            Query query = (Query) em.createQuery("SELECT sub.id FROM Subject sub");
            return query.getResultList();
        } finally {
            em.close();
        }
    }
}


class UpdateSubjectORM {
    public void updateRecord(int id, String name, String semester, int credits) {
        EntityManagerFactory emf = HibernateUtil.getEntityManagerFactory();
        EntityManager em = emf.createEntityManager();
        EntityTransaction transaction = null;

        try {
            transaction = em.getTransaction();
            transaction.begin();

            Subject subject = em.find(Subject.class, id);
            if (subject != null) {
                subject.setName(name);
                subject.setSemester(semester);
                subject.setCredits(credits);

                em.merge(subject);
            } else {
                System.out.println("subject with ID " + id + " does not exist.");
            }

            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            em.close();
        }
    }
}

class DeleteSubjectORM {
    public void deleteRecord(int id) {
        EntityManagerFactory emf = HibernateUtil.getEntityManagerFactory();
        EntityManager em = emf.createEntityManager();
        EntityTransaction transaction = null;

        try {
            transaction = em.getTransaction();
            transaction.begin();

            Subject subject = em.find(Subject.class, id);
            if (subject != null) {
                em.remove(subject);
            } else {
                System.out.println("subject with ID " + id + " does not exist.");
            }

            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            em.close();
        }
    }
}

