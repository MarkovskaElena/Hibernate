package com.myapp.entities;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;

import java.util.List;

public class HibernateUtil {

    private static EntityManagerFactory entityManagerFactory;
    private static EntityManager entityManager;

    public static EntityManagerFactory getEntityManagerFactory() {
        if (entityManagerFactory == null) {
            entityManagerFactory = Persistence.createEntityManagerFactory("Education");
        }
        return entityManagerFactory;
    }

    public static void shutdown() {
        if (entityManagerFactory != null) {
            entityManagerFactory.close();
        }
    }

    public static void main(String[] args) {
        // Create an EntityManagerFactory (adjust the persistence unit name as necessary)
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("Education");
        EntityManager em = emf.createEntityManager();

        try {
            em.getTransaction().begin();

            // Query 1: Get the average age of professors grouped by faculty
//            String hql1 = "SELECT f.name as faculty_name, AVG(p.age) as average_age " +
//                    "FROM Professor p JOIN p.faculty f " +
//                    "GROUP BY f.name";
//            TypedQuery<Object[]> query1 = em.createQuery(hql1, Object[].class);
//            List<Object[]> results1 = query1.getResultList();
//
//            for (Object[] result : results1) {
//                String facultyName = (String) result[0];
//                Double averageAge = (Double) result[1];
//                System.out.println("Faculty: " + facultyName + ", Average Age: " + String.format("%.4f", averageAge));
//            }
//
            // Query 2: Count professors by subject
//            String hql2 = "SELECT s.name as subject_name, COUNT(p.id) as professor_count FROM Professor p JOIN Subject s ON p.primarySubject = s.name GROUP BY s.name";
//            TypedQuery<Object[]> query2 = em.createQuery(hql2, Object[].class);
//            List<Object[]> results2 = query2.getResultList();
//
//            for (Object[] result : results2) {
//                String subjectName = (String) result[0];
//                Long professorCount = (Long) result[1];
//                System.out.println("Subject name: " + subjectName + ", Professor count: " + professorCount);
//            }
//
//            // Query 3: Get students and their assigned professors
//            String hql3 = "SELECT s.id, s.name, s.surname, p.id, p.name, p.surname " +
//                    "FROM Student s JOIN s.professor p " +
//                    "WHERE p.id = 11";
//            TypedQuery<Object[]> query3 = em.createQuery(hql3, Object[].class);
//            List<Object[]> results3 = query3.getResultList();
//
//            for (Object[] result : results3) {
//                Integer studentId = (Integer) result[0];
//                String sName = (String) result[1];
//                String sSurname = (String) result[2];
//                Integer professorId = (Integer) result[3];
//                String pName = (String) result[4];
//                String pSurname = (String) result[5];
//                System.out.println("StudentId: " + studentId + ", Name: " + sName + ", Surname: " + sSurname +
//                        ", ProfessorId: " + professorId + ", Professor Name: " + pName + ", Professor Surname: " + pSurname);
//            }


//            String hql4 = "SELECT s.id, s.name, s.surname, s.location, s.indeks, s.professor.id " +
//                    "FROM Student s JOIN Professor p ON s.professor.id = p.id JOIN Faculty f ON f.id = p.faculty.id " +
//                    "WHERE f.id = 1";
//            TypedQuery<Object[]> query4 = em.createQuery(hql4, Object[].class);
//            List<Object[]> results4 = query4.getResultList();
//
//            for (Object[] result : results4) {
//                Integer studentId = (Integer) result[0];
//                String name = (String) result[1];
//                String surname = (String) result[2];
//                String location = (String) result[3];
//                Integer indeks = (Integer) result[4];
//                Integer professorId = (Integer) result[5];
//
//                System.out.println("Student ID: " + studentId + ", Name: " + name + ", Surname: " + surname +
//                        ", Location: " + location + ", Indeks: " + indeks + ", Professor ID: " + professorId);
//            }

//            String hql5 = "SELECT p.name as professor_name, p.surname as professor_surname, COUNT(s.id) as student_count " +
//                    "FROM Student s JOIN s.professor p JOIN p.faculty f JOIN f.university u " +
//                    "WHERE u.id = 2 " +
//                    "GROUP BY p.id";
//            TypedQuery<Object[]> query5 = em.createQuery(hql5, Object[].class);
//            List<Object[]> results5 = query5.getResultList();
//
//            for (Object[] result : results5) {
//                String professorName = (String) result[0];
//                String professorSurname = (String) result[1];
//                Long studentCount = (Long) result[2];
//                System.out.println("Professor: " + professorName + " " + professorSurname + ", Student Count: " + studentCount);
//            }

//            String hql6 = "SELECT s2.id as student_id, SUM(s.credits) as total_credits " +
//                    "FROM Subject s JOIN Student s2 ON s2.id = s.student.id " +
//                    "GROUP BY s2.id";
//            TypedQuery<Object[]> query6 = em.createQuery(hql6, Object[].class);
//            List<Object[]> results6 = query6.getResultList();
//
//            for (Object[] result : results6) {
//                Integer studentId = (Integer) result[0];
//                Long totalCredits = (Long) result[1];
//                System.out.println("Student ID: " + studentId + ", Total Credits: " + totalCredits);
//            }

//            String hql7 = "SELECT s1.id AS student_id, COUNT(s2.id) AS subject_count " +
//                    "FROM Student s1 JOIN s1.subjects s2 " +
//                    "GROUP BY s1.id";
//            TypedQuery<Object[]> query7 = em.createQuery(hql7, Object[].class);
//            List<Object[]> results7 = query7.getResultList();
//
//            for (Object[] result : results7) {
//                Integer studentId = (Integer) result[0];
//                Long subjectCount = (Long) result[1];
//                System.out.println("Student ID: " + studentId + ", Subject Count: " + subjectCount);
//            }

            em.getTransaction().commit();
        } catch (Exception ex) {
            em.getTransaction().rollback();
            ex.printStackTrace();
        } finally {
            em.close();
            emf.close();
        }
    }
}

