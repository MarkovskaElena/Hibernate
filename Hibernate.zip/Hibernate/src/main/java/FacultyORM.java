import com.myapp.entities.*;
import com.myapp.entities.Faculty;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import org.hibernate.query.Query;

import java.util.List;

public class FacultyORM {
    public static void main(String[] args) {
        InsertFacultyORM insertFacultyORM = new InsertFacultyORM();
        SelectFacultyORM selectFacultyORM = new SelectFacultyORM();
        UpdateFacultyORM updateFacultyORM = new UpdateFacultyORM();
        DeleteFacultyORM deleteFacultyORM = new DeleteFacultyORM();

        try {

            System.out.println("\nAll IDs:");
            List<Integer> allIds = selectFacultyORM.getAllIds();
            System.out.println(allIds);

            System.out.println("\nGet faculty by ID 1:");
            selectFacultyORM.selectById(1);

            System.out.println("\nGet faculty by ID 16:");
            selectFacultyORM.selectById(16);

            insertFacultyORM.insertRecord("Faculty of Toronto", "Toronto, ON", "Business", 5);
            System.out.println("\nAfter inserting a new record:");
            selectFacultyORM.selectAllRecords();

            updateFacultyORM.updateRecord(4, "Berkeley, CA", "Skopje, MK", "Business");

            System.out.println("\nGet faculty by updated ID 27:");
            selectFacultyORM.selectById(27);

            deleteFacultyORM.deleteRecord(12);  // Adjust the ID based on your data
            System.out.println("\nAfter deleting record with ID 12:");
            selectFacultyORM.selectAllRecords();

            System.out.println("All IDs after delete:");
            allIds = selectFacultyORM.getAllIds();
            System.out.println(allIds);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            HibernateUtil.shutdown();
        }
    }
}

class InsertFacultyORM {
    public void insertRecord(String name, String location, String study_field, int universityId) {
        EntityManagerFactory emf = HibernateUtil.getEntityManagerFactory();
        EntityManager em = emf.createEntityManager();
        EntityTransaction transaction = null;

        try {
            transaction = em.getTransaction();
            transaction.begin();

            University university = em.find(University.class, universityId);
            if (university == null) {
                throw new IllegalArgumentException("University with ID " + universityId + " does not exist.");
            }

            Faculty faculty = new Faculty();
            faculty.setName(name);
            faculty.setLocation(location);
            faculty.setStudyField(study_field);
            faculty.setUniversity(university);

            em.persist(faculty);

            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            em.close();
        }
    }
}


class SelectFacultyORM {

    public void selectAllRecords() {
        EntityManagerFactory emf = HibernateUtil.getEntityManagerFactory();
        EntityManager em = emf.createEntityManager();

        try {
            List<Faculty> facultys = em.createQuery("FROM Faculty", Faculty.class).getResultList();
            for (Faculty faculty : facultys) {
                System.out.println(faculty.getId() + ", " + faculty.getName() + ", " + faculty.getLocation());
            }
        } finally {
            em.close();
        }
    }

    public void selectById(int id) {
        EntityManagerFactory emf = HibernateUtil.getEntityManagerFactory();
        EntityManager em = emf.createEntityManager();

        try {
            Faculty faculty = em.find(Faculty.class, id);
            if (faculty != null) {
                System.out.println(faculty.getId() + ", " + faculty.getName() + ", " + faculty.getLocation());
            } else {
                System.out.println("No faculty found with ID " + id);
            }
        } finally {
            em.close();
        }
    }

    public List<Integer> getAllIds() {
        EntityManagerFactory emf = HibernateUtil.getEntityManagerFactory();
        EntityManager em = emf.createEntityManager();

        try {
            Query query = (Query) em.createQuery("SELECT f.id FROM Faculty f");
            return query.getResultList();
        } finally {
            em.close();
        }
    }
}


class UpdateFacultyORM {
    public void updateRecord(int id, String name, String location, String study_field) {
        EntityManagerFactory emf = HibernateUtil.getEntityManagerFactory();
        EntityManager em = emf.createEntityManager();
        EntityTransaction transaction = null;

        try {
            transaction = em.getTransaction();
            transaction.begin();

            Faculty faculty = em.find(Faculty.class, id);
            if (faculty != null) {
                faculty.setName(name);
                faculty.setLocation(location);
                faculty.setStudyField(study_field);

                em.merge(faculty);
            } else {
                System.out.println("faculty with ID " + id + " does not exist.");
            }

            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            em.close();
        }
    }
}

class DeleteFacultyORM {
    public void deleteRecord(int id) {
        EntityManagerFactory emf = HibernateUtil.getEntityManagerFactory();
        EntityManager em = emf.createEntityManager();
        EntityTransaction transaction = null;

        try {
            transaction = em.getTransaction();
            transaction.begin();

            Faculty faculty = em.find(Faculty.class, id);
            if (faculty != null) {
                em.remove(faculty);
            } else {
                System.out.println("faculty with ID " + id + " does not exist.");
            }

            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            em.close();
        }
    }
}

