import com.myapp.entities.HibernateUtil;
import com.myapp.entities.Student;
import org.hibernate.query.Query;
import java.util.List;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.EntityManagerFactory;

public class StudentORM {
    public static void main(String[] args) {
        InsertStudentORM insertStudentORM = new InsertStudentORM();
        SelectStudentORM selectStudentORM = new SelectStudentORM();
        UpdateStudentORM updateStudentORM = new UpdateStudentORM();
        DeleteStudentORM deleteStudentORM = new DeleteStudentORM();

        try {

            System.out.println("\nAll IDs:");
            List<Integer> allIds = selectStudentORM.getAllIds();
            System.out.println(allIds);

            System.out.println("\nGet student by ID 1:");
            selectStudentORM.selectById(1);

            insertStudentORM.insertRecord("Thor", "Thorbor", "Toronto", 113);
            System.out.println("\nAfter inserting a new record:");
            selectStudentORM.selectAllRecords();

            updateStudentORM.updateRecord(4, "Anna", "Sofia", "Skopje, MK", 111);

            System.out.println("\nGet student by updated ID 1:");
            selectStudentORM.selectById(1);

            deleteStudentORM.deleteRecord(12);  // Adjust the ID based on your data
            System.out.println("\nAfter deleting record with ID 12:");
            selectStudentORM.selectAllRecords();

            System.out.println("All IDs after delete:");
            allIds = selectStudentORM.getAllIds();
            System.out.println(allIds);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            HibernateUtil.shutdown();
        }
    }
}

class InsertStudentORM {
    public void insertRecord(String name, String surname, String location, int indeks) {
        EntityManagerFactory emf = HibernateUtil.getEntityManagerFactory();
        EntityManager em = emf.createEntityManager();
        EntityTransaction transaction = null;

        try {
            transaction = em.getTransaction();
            transaction.begin();

            Student student = new Student();
            student.setName(name);
            student.setSurname(surname);
            student.setLocation(location);
            student.setIndeks(indeks);

            em.persist(student);

            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            em.close();
        }
    }
}


class SelectStudentORM {

    public void selectAllRecords() {
        EntityManagerFactory emf = HibernateUtil.getEntityManagerFactory();
        EntityManager em = emf.createEntityManager();

        try {
            List<Student> students = em.createQuery("FROM Student", Student.class).getResultList();
            for (Student student : students) {
                System.out.println(student.getId() + ", " + student.getName() + ", " +  student.getSurname() + ", " + student.getLocation() + ", " + student.getIndeks());            }
        } finally {
            em.close();
        }
    }

    public void selectById(int id) {
        EntityManagerFactory emf = HibernateUtil.getEntityManagerFactory();
        EntityManager em = emf.createEntityManager();

        try {
            Student student = em.find(Student.class, id);
            if (student != null) {
                System.out.println(student.getId() + ", " + student.getName() + ", " + student.getSurname() + ", " + student.getLocation() + ", " + student.getIndeks());
            } else {
                System.out.println("No student found with ID " + id);
            }
        } finally {
            em.close();
        }
    }

    public List<Integer> getAllIds() {
        EntityManagerFactory emf = HibernateUtil.getEntityManagerFactory();
        EntityManager em = emf.createEntityManager();

        try {
            Query query = (Query) em.createQuery("SELECT s.id FROM Student s");
            return query.getResultList();
        } finally {
            em.close();
        }
    }
}


class UpdateStudentORM {
    public void updateRecord(int id, String name, String surname, String location, int indeks) {
        EntityManagerFactory emf = HibernateUtil.getEntityManagerFactory();
        EntityManager em = emf.createEntityManager();
        EntityTransaction transaction = null;

        try {
            transaction = em.getTransaction();
            transaction.begin();

            Student student = em.find(Student.class, id);
            if (student != null) {
                student.setName(name);
                student.setSurname(surname);
                student.setLocation(location);
                student.setIndeks(indeks);

                em.merge(student);
            } else {
                System.out.println("student with ID " + id + " does not exist.");
            }

            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            em.close();
        }
    }
}

class DeleteStudentORM {
    public void deleteRecord(int id) {
        EntityManagerFactory emf = HibernateUtil.getEntityManagerFactory();
        EntityManager em = emf.createEntityManager();
        EntityTransaction transaction = null;

        try {
            transaction = em.getTransaction();
            transaction.begin();

            Student student = em.find(Student.class, id);
            if (student != null) {
                em.remove(student);
            } else {
                System.out.println("student with ID " + id + " does not exist.");
            }

            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            em.close();
        }
    }
}

