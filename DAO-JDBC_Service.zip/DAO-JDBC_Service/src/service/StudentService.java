package service;

import model.Student;

import java.sql.SQLException;
import java.util.List;

public interface StudentService {

    List<Student> getAllFaculty() throws SQLException;

    Student getById(Long id) throws SQLException;

    void update(Student student);

    void delete(Long id) throws SQLException;

    void save(Student student);

}
