package service;

import model.Subject;

import java.sql.SQLException;
import java.util.List;

public interface SubjectService {

    List<Subject> getAllFaculty() throws SQLException;

    Subject getById(Long id) throws SQLException;

    void update(Subject subject);

    void delete(Long id) throws SQLException;

    void save(Subject subject);

}
