package model;

import java.util.Objects;

public class University {

    private Long id;

    private String name;

    private String location;

    private Boolean IsPrivate;

    public University(Long id, String name, String location, Boolean IsPrivate) {
        this.id = id;
        this.name = name;
        this.location = location;
        this.IsPrivate = IsPrivate;
    }

    public University() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Boolean getIsPrivate() {
        return IsPrivate;
    }

    public void setIsPrivate(Boolean IsPrivate) {
        IsPrivate = IsPrivate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        University that = (University) o;
        return IsPrivate == that.IsPrivate && Objects.equals(id, that.id) && Objects.equals(name, that.name) && Objects.equals(location, that.location);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, location, IsPrivate);
    }

    @Override
    public String toString() {
        return id + " " + name + " " + location + " " + IsPrivate ;
    }

}
