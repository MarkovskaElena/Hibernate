package model;

import java.util.Objects;

public class Student {
    private Long id;

    private String name;

    private String surname;

    private String location;

    private int indeks;

    public Student(Long id, String name, String surname, String location, int indeks) {
        this.id = id;
        this.name = name;
        this.surname = surname;
        this.location = location;
        this.indeks = indeks;
    }

    public Student() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public int getIndeks() {
        return indeks;
    }

    public void setIndeks(int indeks) {
        this.indeks = indeks;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Student student = (Student) o;
        return indeks == student.indeks && Objects.equals(id, student.id) && Objects.equals(name, student.name) && Objects.equals(surname, student.surname) && Objects.equals(location, student.location);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, surname, location, indeks);
    }

    @Override
    public String toString(){
        return id + " " + name + " " + surname + " " + location + " " + indeks;
    }
}
