package DAO.impl;

import DAO.JDBCUtils;
import DAO.UniversityDAO;
import model.University;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UniversityDAOImpl implements UniversityDAO {
    @Override
    public List<University> getAll() throws SQLException {
        final String SELECT_ALL_UNIVERSITY = "SELECT * FROM university;";

        List<University> universityList = new ArrayList<>();

        try (Connection connection = JDBCUtils.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_UNIVERSITY)) {
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                long id = rs.getLong("id");
                String name = rs.getString("name");
                String location = rs.getString("location");
                Boolean IsPrivate = rs.getBoolean("IsPrivate");

                System.out.println(id + ", " + name + ", " + location + ", " + IsPrivate);

                University university = new University(id, name, location, IsPrivate);
                universityList.add(university);
            }
        } catch (SQLException e) {
            System.err.println("Error updating Faculty: " + e.getMessage());
            throw e;
            //JDBCUtils.printSQLException(e);
        }
        return universityList;
    }

    @Override
    public University getByID(Long id) throws SQLException {
        final String SELECT_BY_ID = "SELECT * FROM University WHERE id = ?;";
        University university = null;
        try (Connection connection = JDBCUtils.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_BY_ID)) {
            preparedStatement.setLong(1, id);
            ResultSet rs = preparedStatement.executeQuery();
            if(rs.next()) {
                String name = rs.getString("name");
                String location = rs.getString("location");
                Boolean IsPrivate = rs.getBoolean("IsPrivate");
                System.out.println(id + ", " + name + ", " + location + ", " + IsPrivate);
            }
            else {
                System.out.println("No University found with ID " + id);
            }
        }
        catch (SQLException e) {
            JDBCUtils.printSQLException(e);
        }
        return university;
    }

    @Override
    public void update(University university) throws SQLException {
        final String UPDATE_UNIVERSITY_SQL = "UPDATE university SET name = ?, location = ?, IsPrivate = ? WHERE id = ?;";

            try (Connection connection = JDBCUtils.getConnection();
                 PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_UNIVERSITY_SQL)) {
                preparedStatement.setString(1, university.getName());
                preparedStatement.setString(2, university.getLocation());
                preparedStatement.setInt(3, university.getIsPrivate() ? 1 : 0);
                preparedStatement.setLong(4, university.getId());
                preparedStatement.executeUpdate();
            } catch (SQLException e) {
                JDBCUtils.printSQLException(e);
            }
    }

    @Override
    public University save(University university) throws SQLException {
        final String INSERT_UNIVERSITY_SQL = "INSERT INTO university (name, location, IsPrivate) VALUES (?, ?, ?);";
        University universityU = null;
            try (Connection connection = JDBCUtils.getConnection();
                 PreparedStatement preparedStatement = connection.prepareStatement(INSERT_UNIVERSITY_SQL)) {
                preparedStatement.setString(1, university.getName());
                preparedStatement.setString(2, university.getLocation());
                preparedStatement.setInt(3, university.getIsPrivate() ? 1 : 0);
                preparedStatement.executeUpdate();
            } catch (SQLException e) {
                System.err.println("Error updating University: " + e.getMessage());
                throw e;
                //JDBCUtils.printSQLException(e);
            }
            return universityU;
    }

    @Override
    public void delete(Long id) throws SQLException {
        final String DELETE_UNIVERSITY_SQL = "DELETE FROM university WHERE id = ?;";

        try (Connection connection = JDBCUtils.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(DELETE_UNIVERSITY_SQL)) {
            preparedStatement.setLong(1, id);
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("University with ID " + id + " was deleted successfully!");
            } else {
                System.out.println("No University found with ID " + id);
            }
        } catch (SQLException e) {
            System.err.println("Error updating University: " + e.getMessage());
            throw e;
            //JDBCUtils.printSQLException(e);
        }
    }
}
