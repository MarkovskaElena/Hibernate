package DAO.impl;
import DAO.JDBCUtils;
import DAO.StudentDAO;
import model.Student;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class StudentDAOImpl implements StudentDAO{

    @Override
    public List<Student> getAll() throws SQLException {
        final String SELECT_ALL_Student = "SELECT * FROM Student;";

        List<Student> studentList = new ArrayList<>();

        try (Connection connection = JDBCUtils.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_Student)) {
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                long id = rs.getLong("id");
                String name = rs.getString("name");
                String surname = rs.getString("surname");
                String location = rs.getString("location");
                Integer indeks= rs.getInt("indeks");

                Student student = new Student(id, name, surname, location, indeks);
                studentList.add(student);
                System.out.println(id + ", " + name + ", " +  surname + ", " + location + ", " + indeks);
            }
        } catch (SQLException e) {
            System.err.println("Error updating Faculty: " + e.getMessage());
            throw e;
            //JDBCUtils.printSQLException(e);
        }

        return studentList;
    }

    @Override
    public Student getByID(Long id) throws SQLException {
        final String SELECT_BY_ID = "SELECT * FROM Student WHERE id = ?;";
            Student student = null;

        try (Connection connection = JDBCUtils.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_BY_ID)) {
            preparedStatement.setLong(1, id);
            ResultSet rs = preparedStatement.executeQuery();
            if(rs.next()) {
                String name = rs.getString("name");
                String surname = rs.getString("surname");
                String location = rs.getString("location");
                Integer indeks= rs.getInt("indeks");

                System.out.println(id + ", " + name + ", " +  surname + ", " + location + ", " + indeks);            }
            else {
                System.out.println("No Student found with ID " + id);
            }
        }
        catch (SQLException e) {
            System.err.println("Error updating Faculty: " + e.getMessage());
            throw e;
            //JDBCUtils.printSQLException(e);
        }
        return student;
    }


    @Override
    public void update(Student student) throws SQLException {
        final String UPDATE_Student_SQL = "UPDATE Student SET name = ?, surname = ?, location = ?, indeks = ? WHERE id = ?;";

            try (Connection connection = JDBCUtils.getConnection();
                 PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_Student_SQL)) {
                preparedStatement.setString(1, student.getName());
                preparedStatement.setString(2, student.getSurname());
                preparedStatement.setString(3, student.getLocation());
                preparedStatement.setInt(4, student.getIndeks());
                preparedStatement.setLong(5, student.getId());
                preparedStatement.executeUpdate();
            } catch (SQLException e) {
                System.err.println("Error updating Faculty: " + e.getMessage());
                throw e;
                //JDBCUtils.printSQLException(e);
            }
    }

    @Override
    public void save(Student student) throws SQLException {
        final String INSERT_Student_SQL = "INSERT INTO Student (name,surname, location, indeks) VALUES (?, ?, ?, ?);";

            try (Connection connection = JDBCUtils.getConnection();
                 PreparedStatement preparedStatement = connection.prepareStatement(INSERT_Student_SQL)) {
                preparedStatement.setString(1, student.getName());
                preparedStatement.setString(2, student.getSurname());
                preparedStatement.setString(3, student.getLocation());
                preparedStatement.setInt(4, student.getIndeks());
                preparedStatement.executeUpdate();
            } catch (SQLException e) {
                JDBCUtils.printSQLException(e);
            }
    }

    @Override
    public void delete(Long id) throws SQLException {

        final String DELETE_SUBJECTS_BY_STUDENT_ID = "DELETE FROM subject WHERE studentId = ?;";
        try (Connection connection = JDBCUtils.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(DELETE_SUBJECTS_BY_STUDENT_ID)) {
            preparedStatement.setLong(1, id);
            preparedStatement.executeUpdate(); // Delete subjects associated with the student
        }


        final String DELETE_Student_SQL = "DELETE FROM Student WHERE id = ?;";

        try (Connection connection = JDBCUtils.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(DELETE_Student_SQL)) {
            preparedStatement.setLong(1, id);
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Student with ID " + id + " was deleted successfully!");
            } else {
                System.out.println("No Student found with ID " + id);
            }
        } catch (SQLException e) {
            System.err.println("Error updating Student: " + e.getMessage());
            throw e;
            //JDBCUtils.printSQLException(e);
        }
    }
}
