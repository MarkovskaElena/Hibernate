package DAO.impl;

import DAO.JDBCUtils;
import DAO.SubjectDAO;
import model.Student;
import model.Subject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SubjectDAOImpl implements SubjectDAO {

    @Override
    public List<Subject> getAll() throws SQLException {
        final String SELECT_ALL_Subject = "SELECT * FROM Subject;";

        List<Subject> subjectList = new ArrayList<>();
        try (Connection connection = JDBCUtils.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_Subject)) {
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                long id = rs.getLong("id");
                String name = rs.getString("name");
                String semester = rs.getString("semester");
                Integer credits= rs.getInt("credits");
                Long studentId = rs.getLong("studentId");

                System.out.println(id + ", " + name + ", " + semester + ", " + credits);

            }
        } catch (SQLException e) {
            System.err.println("Error updating Subject: " + e.getMessage());
            throw e;
            //JDBCUtils.printSQLException(e);
        }
        return subjectList;
    }

    @Override
    public Subject getByID(Long id) throws SQLException {
        final String SELECT_BY_ID = "SELECT * FROM Subject WHERE id = ?;";
        Subject subject = null;

        try (Connection connection = JDBCUtils.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_BY_ID)) {
            preparedStatement.setLong(1, id);
            ResultSet rs = preparedStatement.executeQuery();
            if(rs.next()) {
                String name = rs.getString("name");
                String semester = rs.getString("semester");
                Integer credits= rs.getInt("credits");

                System.out.println(id + ", " + name + ", " +  semester + ", " + credits);            }
            else {
                System.out.println("No Subject found with ID " + id);
            }
        }
        catch (SQLException e) {
            System.err.println("Error updating Faculty: " + e.getMessage());
            throw e;
            //JDBCUtils.printSQLException(e);
        }
        return subject;
    }

    @Override
    public void update(Subject subject) throws SQLException {
        final String UPDATE_Subject_SQL = "UPDATE Subject SET name = ?, semester = ?, credits = ? WHERE id = ?;";

            try (Connection connection = JDBCUtils.getConnection();
                 PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_Subject_SQL)) {
                preparedStatement.setString(1, subject.getName());
                preparedStatement.setString(2, subject.getSemester());
                preparedStatement.setInt(3, subject.getCredits());
                preparedStatement.setLong(4, subject.getId());
                preparedStatement.executeUpdate();
            } catch (SQLException e) {
                System.err.println("Error updating Faculty: " + e.getMessage());
                throw e;
                //JDBCUtils.printSQLException(e);
            }
    }

    @Override
    public void save(Subject subject) throws SQLException {
        final String INSERT_Subject_SQL = "INSERT INTO Subject (name,semester,credits) VALUES (?, ?, ?);";

            try (Connection connection = JDBCUtils.getConnection();
                 PreparedStatement preparedStatement = connection.prepareStatement(INSERT_Subject_SQL)) {
                preparedStatement.setString(1, subject.getName());
                preparedStatement.setString(2, subject.getSemester());
                preparedStatement.setInt(3, subject.getCredits());
                preparedStatement.executeUpdate();
            } catch (SQLException e) {
                System.err.println("Error updating Faculty: " + e.getMessage());
                throw e;
                //JDBCUtils.printSQLException(e);
            }
    }

    @Override
    public void delete(Long id) throws SQLException {
//        final String DELETE_PROFESSORS_BY_FACULTY_ID = "DELETE FROM professor WHERE faculty_id = ?;";
//        try (Connection connection = JDBCUtils.getConnection();
//             PreparedStatement preparedStatement = connection.prepareStatement(DELETE_PROFESSORS_BY_FACULTY_ID)) {
//            preparedStatement.setLong(1, id);
//            preparedStatement.executeUpdate();
//        }

        final String DELETE_Subject_SQL = "DELETE FROM Subject WHERE id = ?;";

        try (Connection connection = JDBCUtils.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(DELETE_Subject_SQL)) {
            preparedStatement.setLong(1, id);
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Subject with ID " + id + " was deleted successfully!");
            } else {
                System.out.println("No Subject found with ID " + id);
            }
        } catch (SQLException e) {
            System.err.println("Error updating Subject: " + e.getMessage());
            throw e;
            //JDBCUtils.printSQLException(e);
        }
    }
}
