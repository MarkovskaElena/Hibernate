package DAO;

import model.Subject;

import java.sql.SQLException;
import java.util.List;

public interface SubjectDAO {

    List<Subject> getAll() throws SQLException;

    Subject getByID(Long id) throws SQLException;

    void update(Subject subject) throws SQLException;

    void save(Subject subject) throws SQLException;

    void delete(Long id) throws SQLException;
}
