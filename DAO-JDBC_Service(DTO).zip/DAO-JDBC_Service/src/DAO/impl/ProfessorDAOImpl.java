package DAO.impl;

import DAO.JDBCUtils;
import DAO.ProfessorDAO;
import model.Professor;
import model.Student;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class ProfessorDAOImpl implements ProfessorDAO {

    private final Connection connection;

    public ProfessorDAOImpl(Connection connection) {
        this.connection = connection;
    }

    public List<Professor> getall() throws SQLException {

        final String SELECT_ALL_Professor = "SELECT * FROM Professor;";

        List<Professor> professorList = new ArrayList<>();
        try (Connection connection = JDBCUtils.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_Professor)) {
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                long id = rs.getLong("id");
                String name = rs.getString("name");
                String surname = rs.getString("surname");
                Integer age = rs.getInt("age");
                String primarySubject = rs.getString("primarySubject");
                String secondarySubject = rs.getString("secondarySubject");

                System.out.println(id + ", " + name + ", " + surname + ", " + age + ", " + primarySubject + ", " + secondarySubject);
            }
        } catch (SQLException e) {
            System.err.println("Error updating Faculty: " + e.getMessage());
            throw e;
            //JDBCUtils.printSQLException(e);
        }

        return professorList;
    }

    @Override
    public List<Professor> getAllSortedById() throws SQLException {
        final String SELECT_ALL_SORTED = "SELECT * FROM Professor ORDER BY id ASC;";
        List<Professor> professors = new ArrayList<>();

        try (Connection connection = JDBCUtils.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_SORTED)) {
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                long id = rs.getLong("id");
                String name = rs.getString("name");
                String surname = rs.getString("surname");
                Integer age = rs.getInt("age");
                String primarySubject = rs.getString("primarySubject");
                String secondarySubject = rs.getString("secondarySubject");

                professors.add(new Professor(id, name, surname, age, primarySubject, secondarySubject));
            }
        }catch (SQLException e) {
            System.err.println("Error fetching professors: " + e.getMessage());
            throw e;
        }
        return professors;
    }


    @Override
    public Professor getByID(Long id) throws SQLException {

        final String SELECT_BY_ID = "SELECT * FROM Professor WHERE id = ?;";
        Professor professor = null;

        try (Connection connection = JDBCUtils.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_BY_ID)) {
            preparedStatement.setLong(1, id);
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()) {
                String name = rs.getString("name");
                String surname = rs.getString("surname");
                Integer age = rs.getInt("age");
                String primarySubject = rs.getString("primarySubject");
                String secondarySubject = rs.getString("secondarySubject");

                System.out.println("ID: " + id + ": " + name + ", " + surname + ", " + age + ", " + primarySubject + ", " + secondarySubject);
            } else {
                System.out.println("No professor found with ID " + id);
            }
        } catch (SQLException e) {
            System.err.println("Error updating Faculty: " + e.getMessage());
            throw e;
            //JDBCUtils.printSQLException(e);
        }
        return professor;
    }

    @Override
    public void update(Professor professor) throws SQLException {

        final String UPDATE_Professor_SQL = "UPDATE Professor SET name = ?, surname = ?, age = ?, primarySubject = ?, secondarySubject = ? WHERE id = ?;";

        try (Connection connection = JDBCUtils.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_Professor_SQL)) {
            preparedStatement.setString(1, professor.getName());
            preparedStatement.setString(2, professor.getSurname());
            preparedStatement.setInt(3, professor.getAge());
            preparedStatement.setString(4, professor.getPrimarySubject());
            preparedStatement.setString(5, professor.getSecondarySubject());
            preparedStatement.setLong(6, professor.getId());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error updating Faculty: " + e.getMessage());
            throw e;
            // JDBCUtils.printSQLException(e);
        }
    }

    @Override
    public void save(Professor professor) throws SQLException {
        final String INSERT_Professor_SQL = "INSERT INTO Professor (name,surname, age, primarySubject, secondarySubject) VALUES (?, ?, ?, ?, ?);";

        try (Connection connection = JDBCUtils.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_Professor_SQL)) {
            preparedStatement.setString(1, professor.getName());
            preparedStatement.setString(2, professor.getSurname());
            preparedStatement.setInt(3, professor.getAge());
            preparedStatement.setString(4, professor.getPrimarySubject());
            preparedStatement.setString(5, professor.getSecondarySubject());

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error updating Faculty: " + e.getMessage());
            throw e;
            //JDBCUtils.printSQLException(e);
        }
    }


    @Override
    public void delete(Long id) {

    }

    public void deleteRange(long l, long l1) {
    }

    @Override
    public Map<String, Double> findAverageAgeByFaculty() {
        String query = """
                SELECT f.name as faculty_name, AVG(p.age) as average_age
                FROM professor p
                JOIN faculty f ON f.id = p.faculty_id
                GROUP BY f.name;
                """;
        Map<String, Double> result = new HashMap<>();
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String facultyName = rs.getString("faculty_name");
                double averageAge = rs.getDouble("average_age");
                result.put(facultyName, averageAge);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public Map<String, Integer> findProfessorCountBySubject() {
        String query = """
                            
                SELECT s.name as subject_name, COUNT(p.id) as professor_count
                            FROM professor p
                            JOIN subject s ON p.
                primarySubject 
                        GROUP BY s.name;
            """;
        Map<String, Integer> result = new HashMap<>();
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String subjectName = rs.getString("subject_name");
                int professorCount = rs.getInt("professor_count");
                result.put(subjectName, professorCount);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }


    @Override
    public List<Student> findStudentsByUniversityId(int universityId) {
        String query = """
            SELECT s.id, s.name, s.surname, s.location, s.indeks, s.professor_id
            FROM student s 
            JOIN professor p ON s.professor_id = p.id 
            JOIN faculty f ON f.id = p.faculty_id 
            JOIN university u ON f.university_id = u.id 
            WHERE u.id = ?;
        """;

        List<Student> students = new ArrayList<>();

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, universityId);  // Set the university ID parameter

            ResultSet rs = stmt.executeQuery();

            // Iterate through the result set and map to Student objects
            while (rs.next()) {
                Long studentId = rs.getLong("id");
                String name = rs.getString("name");
                String surname = rs.getString("surname");
                String location = rs.getString("location");
                int indeks = rs.getInt("indeks");
                Long professorId = rs.getLong("professor_id");

                // Create and add the Student object to the list
                Student student = new Student(studentId, name, surname, location, indeks);
                students.add(student);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return students;
    }

    @Override
    public List<Student> findStudentsByFacultyId(int facultyId) {
        String query = """
            SELECT s.id, s.name, s.surname, s.location, s.indeks, s.professor_id
            FROM student s 
            JOIN professor p ON s.professor_id = p.id 
            JOIN faculty f ON f.id = p.faculty_id 
            WHERE f.id = ?;
        """;

        List<Student> students = new ArrayList<>();

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, facultyId);  // Set the faculty ID parameter

            ResultSet rs = stmt.executeQuery();

            // Iterate through the result set and map to Student objects
            while (rs.next()) {
                Long studentId = rs.getLong("id");
                String name = rs.getString("name");
                String surname = rs.getString("surname");
                String location = rs.getString("location");
                int indeks = rs.getInt("indeks");
                Long professorId = rs.getLong("professor_id");

                // Create and add the Student object to the list
                Student student = new Student(studentId, name, surname, location, indeks);
                students.add(student);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return students;
    }
    }






