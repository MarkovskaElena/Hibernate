package DAO.impl;
import DAO.JDBCUtils;
import DAO.StudentDAO;
import model.Student;
import model.Subject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class StudentDAOImpl implements StudentDAO{

    @Override
    public List<Student> getAll() throws SQLException {
        final String SELECT_ALL_Student = "SELECT * FROM Student;";

        List<Student> studentList = new ArrayList<>();

        try (Connection connection = JDBCUtils.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_Student)) {
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                long id = rs.getLong("id");
                String name = rs.getString("name");
                String surname = rs.getString("surname");
                String location = rs.getString("location");
                Integer indeks= rs.getInt("indeks");

                Student student = new Student(id, name, surname, location, indeks);
                studentList.add(student);
                System.out.println(id + ", " + name + ", " +  surname + ", " + location + ", " + indeks);
            }
        } catch (SQLException e) {
            System.err.println("Error updating Faculty: " + e.getMessage());
            throw e;
            //JDBCUtils.printSQLException(e);
        }

        return studentList;
    }


    @Override
    public List<Student> getStudentsWithOddLengthNames() throws SQLException {
        final String QUERY = "SELECT id, name, surname, location, indeks, faculty_id FROM student WHERE LENGTH(name) % 2 = 1";
        List<Student> students = new ArrayList<>();

        try (Connection connection = JDBCUtils.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(QUERY)) {

            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                Long id = rs.getLong("id");
                String name = rs.getString("name");
                String surname = rs.getString("surname");
                String location = rs.getString("location"); // Can be null
                int indeks = rs.getInt("indeks");
                Long facultyId = rs.getObject("faculty_id") != null ? rs.getLong("faculty_id") : null; // Handle null faculty_id

                Student student = new Student(id, name, surname, location, indeks, facultyId);
                students.add(student);

                // Debugging
                System.out.println("Fetched: " + id + ", " + name + ", " + surname + ", " +
                        (location != null ? location : "NULL") + ", " + indeks + ", " + (facultyId != null ? facultyId : "NULL"));
            }
        }
        return students;
    }




    @Override
    public Student getStudentById(Long id) throws SQLException {
        final String QUERY = "SELECT s.id, s.name, s.surname, s.indeks, s.location, f.name AS faculty_name, s.faculty_id " +
                "FROM Student s JOIN faculty f ON s.faculty_id = f.id " +
                "WHERE s.id = ?";

        try (Connection connection = JDBCUtils.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(QUERY)) {
            preparedStatement.setLong(1, id);
            ResultSet rs = preparedStatement.executeQuery();

            if (rs.next()) {
                String name = rs.getString("name");
                String surname = rs.getString("surname");
                String location = rs.getString("location");
                int indeks = rs.getInt("indeks");
                String facultyName = rs.getString("faculty_name");
                Long facultyId = rs.getLong("faculty_id");
                List<Subject> passedSubjects = getPassedSubjectsByStudentId(id);

                return new Student(id, name, surname, location, indeks, facultyName, facultyId, passedSubjects);
            } else {
                System.out.println("No student found with ID " + id);
                return null;
            }
        }
    }

    private List<Subject> getPassedSubjectsByStudentId(Long id) {
        return List.of();
    }

    @Override
    public Student getByID(Long id) throws SQLException {
        final String SELECT_BY_ID = "SELECT * FROM Student WHERE id = ?;";
            Student student = null;

        try (Connection connection = JDBCUtils.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_BY_ID)) {
            preparedStatement.setLong(1, id);
            ResultSet rs = preparedStatement.executeQuery();
            if(rs.next()) {
                String name = rs.getString("name");
                String surname = rs.getString("surname");
                String location = rs.getString("location");
                Integer indeks= rs.getInt("indeks");

                System.out.println(id + ", " + name + ", " +  surname + ", " + location + ", " + indeks);            }
            else {
                System.out.println("No Student found with ID " + id);
            }
        }
        catch (SQLException e) {
            System.err.println("Error updating Faculty: " + e.getMessage());
            throw e;
            //JDBCUtils.printSQLException(e);
        }
        return student;
    }


    @Override
    public void update(Student student) throws SQLException {
        final String UPDATE_Student_SQL = "UPDATE Student SET name = ?, surname = ?, location = ?, indeks = ? WHERE id = ?;";

            try (Connection connection = JDBCUtils.getConnection();
                 PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_Student_SQL)) {
                preparedStatement.setString(1, student.getName());
                preparedStatement.setString(2, student.getSurname());
                preparedStatement.setString(3, student.getLocation());
                preparedStatement.setInt(4, student.getIndeks());
                preparedStatement.setLong(5, student.getId());
                preparedStatement.executeUpdate();
            } catch (SQLException e) {
                System.err.println("Error updating Faculty: " + e.getMessage());
                throw e;
                //JDBCUtils.printSQLException(e);
            }
    }

    @Override
    public void save(Student student) throws SQLException {
        final String INSERT_Student_SQL = "INSERT INTO Student (name,surname, location, indeks) VALUES (?, ?, ?, ?);";

            try (Connection connection = JDBCUtils.getConnection();
                 PreparedStatement preparedStatement = connection.prepareStatement(INSERT_Student_SQL)) {
                preparedStatement.setString(1, student.getName());
                preparedStatement.setString(2, student.getSurname());
                preparedStatement.setString(3, student.getLocation());
                preparedStatement.setInt(4, student.getIndeks());
                preparedStatement.executeUpdate();
            } catch (SQLException e) {
                JDBCUtils.printSQLException(e);
            }
    }

    @Override
    public void delete(Long id) throws SQLException {

        final String DELETE_SUBJECTS_BY_STUDENT_ID = "DELETE FROM subject WHERE studentId = ?;";
        try (Connection connection = JDBCUtils.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(DELETE_SUBJECTS_BY_STUDENT_ID)) {
            preparedStatement.setLong(1, id);
            preparedStatement.executeUpdate(); // Delete subjects associated with the student
        }


        final String DELETE_Student_SQL = "DELETE FROM Student WHERE id = ?;";

        try (Connection connection = JDBCUtils.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(DELETE_Student_SQL)) {
            preparedStatement.setLong(1, id);
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Student with ID " + id + " was deleted successfully!");
            } else {
                System.out.println("No Student found with ID " + id);
            }
        } catch (SQLException e) {
            System.err.println("Error updating Student: " + e.getMessage());
            throw e;
            //JDBCUtils.printSQLException(e);
        }
    }
}
