import DAO.ProfessorDAO;
import DAO.StudentDAO;
import DAO.SubjectDAO;
import DAO.impl.*;
import model.*;
import service.impl.ProfessorServiceImpl;
import java.util.ArrayList;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) throws SQLException {

        String URL = "jdbc:mysql://localhost:3306/Education?useSSL=false&allowPublicKeyRetrieval=true";
        String USER = "root";
        String PASSWORD = "12345Em!";

        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {

//            StudentDAOImpl studentDAO = new StudentDAOImpl();
//            SubjectDAOImpl subjectDAO = new SubjectDAOImpl();
//
//            Long studentId = 15L;
//
//            try {
//                Student student = studentDAO.getStudentById(studentId);
//                if (student == null) {
//                    System.out.println("No student found with ID: " + studentId);
//                    return;
//                }
//                List<Subject> passedSubjects = subjectDAO.getPassedSubjectsByStudentId(studentId);
//                double averageGrade = passedSubjects.stream()
//                        .mapToInt(Subject::getGrade)
//                        .average()
//                        .orElse(0.0);
//
//                System.out.println("Student: " + student.getName() + " " + student.getSurname());
//                System.out.println("Index: " + student.getIndeks());
//                System.out.println("Faculty: " + student.getFacultyName());
//                System.out.println("Passed Subjects:");
//                for (Subject subject : passedSubjects) {
//                    System.out.println("- " + subject.getName() + " (Grade: " + subject.getGrade() + ")");
//                }
//                System.out.println("Average Grade: " + averageGrade);
//            } catch (SQLException e) {
//                System.err.println("Error: " + e.getMessage());
//            }



//            ProfessorDAO professorDAO = new ProfessorDAOImpl(connection);
//            UniversityDAOImpl universityDAO = new UniversityDAOImpl();
//            StudentDAOImpl studentDAO = new StudentDAOImpl();
//
//            try {
//                List<Professor> professors = professorDAO.getAllSortedById();
//                System.out.println("Professors (sorted by ID):");
//                for (Professor professor : professors) {
//                    System.out.println(professor.getId() + ": " + professor.getName() + " " + professor.getSurname());
//                }
//
//                List<University> universities = universityDAO.getUniversitiesInSkopje();
//                System.out.println("\nUniversities in Skopje:");
//                for (University university : universities) {
//                    System.out.println(university.getName() + " - " + university.getLocation());
//                }
//                System.out.println("\nStudents with odd-names:");
//                List<Student> students = studentDAO.getStudentsWithOddLengthNames();
//                for (Student student : students) {
//                    System.out.println();
//                }
//
//            } catch (SQLException e) {
//                System.err.println("Error: " + e.getMessage());
//            }


//            SubjectDAO subjectDAO = new SubjectDAOImpl();
//
//            List<Professor> professors = professorDAO.getall();
//
//            for (Professor professor : professors) {
//                if (professor.getName().length() % 2 == 0) {
//                    System.out.println("Professor: " + professor.getName() + " " + professor.getSurname());
//                    List<Subject> subjects = subjectDAO.getSubjectsByProfessorId(professor.getId());
//                    for (Subject subject : subjects) {
//                        if (subject.getCredits() % 2 != 0) {
//                            System.out.println("Subject: " + subject.getName() + ", Credits: " + subject.getCredits() + ", Semester: " + subject.getSemester());
//                        }
//                    }
//                }
//            }


//            Map<String, Double> averageAgeByFaculty = professorDAO.findAverageAgeByFaculty();
//            averageAgeByFaculty.forEach((faculty, avgAge) ->
//                    System.out.println("Faculty: " + faculty + ", Average Age: " + String.format("%.4f", avgAge))
//            );


//            Map<String, Integer> professorCountBySubject = professorDAO.findProfessorCountBySubject();
//            professorCountBySubject.forEach((subject, count) ->
//                    System.out.println("Subject name: " + subject + ", Professor count: " + count));


//            List<Student> students = professorDAO.findStudentsByUniversityId(2);
//            for (Student student : students) {
//                System.out.println(student);
//            }

//            List<Student> students = professorDAO.findStudentsByFacultyId(1);
//            for (Student student : students) {
//                System.out.println(student);
//            }


            } catch (Exception e) {
                e.printStackTrace();
            }


            //ServiceImplMain

//
//        Connection connection = ProfessorServiceImpl.DatabaseConnection.getConnection();
//            ProfessorServiceImpl professorService = new ProfessorServiceImpl(connection);
//
//            List<Professor> professors = professorService.getAllFaculty();
//            printList("All Professors", professors);
//
//            System.out.println("\nUpdating professor with ID 21...");
//            Professor updatedProfessor = new Professor(21L, "Mary", "Poppins", 35, "English", "History", new ArrayList<>());
//            professorService.update(updatedProfessor);
//            System.out.println("Professor updated successfully.");
//
//            System.out.println("\nDeleting professor with ID 1...");
//            professorService.delete(1L);
//            System.out.println("Professor deleted successfully.");
//            System.out.println("\n");
//
//            professors = professorService.getAllFaculty();
//            printList("Updated Professors", professors);


//        FacultyDAOImpl facultyDAO = new FacultyDAOImpl();
//        List<Faculty> faculties = facultyDAO.getAll();
//        printList("All Faculties", faculties);
//
//        System.out.println("\nUpdating faculty with ID 21...");
//        Faculty updatedFaculty = new Faculty(21L, "Faculty of Engineering", "Stanford, CA", "Engineering", 2L);
//        facultyDAO.update(updatedFaculty);
//        System.out.println("Faculty updated successfully.");
//
//        System.out.println("\nDeleting faculty with ID 1...");
//        facultyDAO.delete(1L);
//        System.out.println("Faculty deleted successfully.");
//
//        faculties = facultyDAO.getAll();
//        printList("Updated Faculties", faculties);


//        StudentDAOImpl studentDAO = new StudentDAOImpl();
//
//        System.out.println("\n--- Handling Students ---");
//
//        List<Student> students = studentDAO.getAll();
//        printList("All Students", students);
//
//        System.out.println("\nUpdating student with ID 14...");
//        Student updatedStudent = new Student(14L, "Henry", "VI", "England", 114);
//        studentDAO.update(updatedStudent);
//        System.out.println("Student updated successfully.");
//
//        System.out.println("\nDeleting student with ID 17...");
//        studentDAO.delete(17L);
//        System.out.println("Student deleted successfully.");
//
//        students = studentDAO.getAll();
//        printList("Updated Students", students);


//         SubjectDAOImpl subjectDAO = new SubjectDAOImpl();
//
//        System.out.println("\n--- Handling Subjects ---");
//
//        List<Subject> subjects = subjectDAO.getAll();
//        printList("All Subjects", subjects);
//
//        System.out.println("\nUpdating subject with ID 14...");
//        Subject updatedSubject = new Subject(14L, "Chemistry", "Spring", 5, 2L);
//        subjectDAO.update(updatedSubject);
//        System.out.println("Subject updated successfully.");
//
//        System.out.println("\nDeleting subject with ID 17...");
//        subjectDAO.delete(17L);
//        System.out.println("Subject deleted successfully.");
//
//        subjects = subjectDAO.getAll();
//        printList("Updated Subjects", subjects);


//        UniversityDAOImpl universityDAO = new UniversityDAOImpl();
//
//        System.out.println("\n--- Handling Universities ---");
//
//        List<University> universities = universityDAO.getAll();
//        printList("All Universities", universities);
//
//        System.out.println("\nUpdating university with ID 1...");
//        University updatedUniversity = new University(1L, "California Institute of Technology", "Pasadena, CA", false);
//        universityDAO.update(updatedUniversity);
//        System.out.println("University updated successfully.");
//
//        System.out.println("\nDeleting university with ID 17...");
//        universityDAO.delete(17L);
//        System.out.println("University deleted successfully.");
//
//        universities = universityDAO.getAll();
//        printList("Updated Universities", universities);


            //DAOImplMain


//        ProfessorDAOImpl professorDAO = new ProfessorDAOImpl(connection);
//        try {
//            System.out.println("Getting all professors before update or delete:");
//            professorDAO.getall();
//
//            System.out.println("\nUpdating professor with ID 21:");
//            Professor updatedProfessor = new Professor(21L, "Mary", "Poppins", 35, "English", "History");
//            professorDAO.update(updatedProfessor);
//
//            System.out.println("\nDeleting professor with ID 1:");
//            professorDAO.delete(1L);
//
//            System.out.println("\nGetting all professors after update and delete:");
//            professorDAO.getall();
//
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }


//        FacultyDAOImpl facultyDAO = new FacultyDAOImpl();
//
//        try {
//            System.out.println("Getting all professors before update or delete:");
//            facultyDAO.getAll();
//
//            System.out.println("\nUpdating professor with ID 21:");
//            Faculty updatedFaculty = new Faculty(21L, "Faculty of Engineering", "Stanford, CA", "Engineering", 2L);
//            facultyDAO.update(updatedFaculty);
//
//            System.out.println("\nDeleting professor with ID 1:");
//            facultyDAO.delete(1L);
//
//            System.out.println("\nGetting all professors after update and delete:");
//            facultyDAO.getAll();
//
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }


//        StudentDAOImpl studentDAO = new StudentDAOImpl();
//
//        try {
//            System.out.println("Getting all students before update or delete:");
//            studentDAO.getAll();
//
//            System.out.println("\nUpdating student with ID 14:");
//            Student updatedStudent = new Student(14L, "Henry", "VI", "England", 114);
//            studentDAO.update(updatedStudent);
//
//            System.out.println("\nDeleting student with ID 17:");
//            studentDAO.delete(17L);
//
//            System.out.println("\nGetting all students after update and delete:");
//            studentDAO.getAll();
//
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }


//        SubjectDAOImpl subjectDAO = new SubjectDAOImpl();
//
//        try {
//            System.out.println("Getting all students before update or delete:");
//            subjectDAO.getAll();
//
//            System.out.println("\nUpdating student with ID 14:");
//            Subject updatedSubject = new Subject(14L, "Chemistry", "Spring", 5, 2L);
//            subjectDAO.update(updatedSubject);
//
//            System.out.println("\nDeleting student with ID 17:");
//            subjectDAO.delete(17L);
//
//            System.out.println("\nGetting all students after update and delete:");
//            subjectDAO.getAll();
//
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }

//        UniversityDAOImpl universityDAO = new UniversityDAOImpl();
//
//        try {
//            System.out.println("Getting all students before update or delete:");
//            universityDAO.getAll();
//
//            System.out.println("\nUpdating student with ID 1:");
//            University updatedUniversity = new University(1L, "California Institute of Technology", "Pasadena, CA", false);
//            universityDAO.update(updatedUniversity);
//
//            System.out.println("\nDeleting student with ID 17:");
//            universityDAO.delete(17L);
//
//            System.out.println("\nGetting all students after update and delete:");
//            universityDAO.getAll();
//
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }


        }

//    private static <T> void printList(String title, List<T> list) {
//        System.out.println("\n" + title + ":");
//        if (list == null || list.isEmpty()) {
//            System.out.println("No records found.");
//        } else {
//            list.forEach(System.out::println);
//        }
//    }
    }



