package service.impl;

import DAO.impl.SubjectDAOImpl;
import model.Subject;
import service.SubjectService;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SubjectServiceImpl implements SubjectService {

    SubjectDAOImpl subjectDAO = new SubjectDAOImpl();

    @Override
    public List<Subject> getAllFaculty() throws SQLException {
        List<Subject> subject = subjectDAO.getAll();
        return subject;
    }

    @Override
    public Subject getById(Long id) throws SQLException {
        try {
            return subjectDAO.getByID(id);
        } catch (SQLException e) {
            System.out.println("Error fetching subject with ID " + id + ": " + e.getMessage());
            throw e;
        }
    }

    @Override
    public void update(Subject subject) {
        try {
            subjectDAO.update(subject);
            System.out.println("Successfully updated subject: " + subject);
        } catch (SQLException e) {
            System.out.println("Error updating subject: " + subject + ". " + e.getMessage());
            throw new RuntimeException("Failed to update subject", e);
        }
    }

    @Override
    public void delete(Long id) throws SQLException {
        subjectDAO.delete(id);
        System.out.println("Successfully deleted subject with ID: " + id);
    }

    @Override
    public void save(Subject subject) {
        try {
            subjectDAO.save(subject);
            System.out.println("Successfully saved subject: " + subject);
        } catch (SQLException e) {
            System.out.println("Error saving subject: " + subject + ". " + e.getMessage());
            throw new RuntimeException("Failed to save subject", e);
        }
    }
}