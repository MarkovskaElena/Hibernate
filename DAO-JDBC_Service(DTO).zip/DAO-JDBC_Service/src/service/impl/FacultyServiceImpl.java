package service.impl;

import DAO.impl.FacultyDAOImpl;
import model.Faculty;
import service.FacultyService;

import java.sql.SQLException;
import java.util.List;

public class FacultyServiceImpl implements FacultyService {

    private final FacultyDAOImpl facultyDAO = new FacultyDAOImpl();

    @Override
    public List<Faculty> getAllFaculty() throws SQLException {
        return facultyDAO.getAll();
    }

    @Override
    public Faculty getById(Long id) throws SQLException {
        return facultyDAO.getByID(id);
    }

    @Override
    public void update(Faculty faculty) {
        try {
            facultyDAO.update(faculty);
            System.out.println("Successfully updated faculty: " + faculty);
        } catch (SQLException e) {
            System.out.println("Error updating faculty: " + faculty + ". " + e.getMessage());
            throw new RuntimeException("Failed to update faculty: " + e.getMessage(), e);
        }
    }

    @Override
    public void delete(Long id) {
        try {
            facultyDAO.delete(id);
            System.out.println("Successfully deleted faculty with ID: " + id);
        } catch (SQLException e) {
            System.out.println("Error deleting faculty with ID " + id + ": " + e.getMessage());
            throw new RuntimeException("Failed to delete faculty: " + e.getMessage(), e);
        }
    }

    @Override
    public void save(Faculty faculty) {
        try {
            facultyDAO.save(faculty);
            System.out.println("Successfully saved faculty: " + faculty);
        } catch (SQLException e) {
            System.out.println("Error saving faculty: " + faculty + ". " + e.getMessage());
            throw new RuntimeException("Failed to save faculty: " + e.getMessage(), e);
        }
    }


}
