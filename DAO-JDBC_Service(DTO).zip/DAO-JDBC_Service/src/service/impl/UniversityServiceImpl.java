package service.impl;

import DAO.impl.UniversityDAOImpl;
import model.University;
import service.UniversityService;

import java.sql.SQLException;
import java.util.List;

public class UniversityServiceImpl implements UniversityService {

    UniversityDAOImpl universityDAO = new UniversityDAOImpl();

    @Override
    public List<University> getAllFaculty() throws SQLException {
        List<University> university = universityDAO.getAll();
        return university;
    }

    @Override
    public University getById(Long id) throws SQLException {
        try {
            return universityDAO.getByID(id);
        } catch (SQLException e) {
            System.out.println("Error fetching university with ID " + id + ": " + e.getMessage());
            throw e;
        }
    }

    @Override
    public void update(University university) {
        try {
            universityDAO.update(university);
            System.out.println("Successfully updated university: " + university);
        } catch (SQLException e) {
            System.out.println("Error updating university: " + university + ". " + e.getMessage());
            throw new RuntimeException("Failed to update university", e);
        }
    }

    @Override
    public void delete(Long id) throws SQLException {
        universityDAO.delete(id);
        System.out.println("Successfully deleted university with ID: " + id);
    }

    @Override
    public void save(University university) {
        try {
            universityDAO.save(university);
            System.out.println("Successfully saved university: " + university);
        } catch (SQLException e) {
            System.out.println("Error saving university: " + university + ". " + e.getMessage());
            throw new RuntimeException("Failed to save university", e);
        }
    }
}
