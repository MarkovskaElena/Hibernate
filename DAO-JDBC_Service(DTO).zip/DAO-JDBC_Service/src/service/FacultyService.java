package service;

import model.Faculty;

import java.sql.SQLException;
import java.util.List;

public interface FacultyService {

    List<Faculty> getAllFaculty() throws SQLException;

    Faculty getById(Long id) throws SQLException;

    void update(Faculty faculty);

    void delete(Long id) throws SQLException;

    void save(Faculty faculty);
}
