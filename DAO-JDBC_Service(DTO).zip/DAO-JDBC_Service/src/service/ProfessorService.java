package service;

import model.Professor;

import java.sql.SQLException;
import java.util.List;

public interface ProfessorService {

    List<Professor> getAllFaculty() throws SQLException;

    Professor getById(Long id) throws SQLException;

    void update(Professor professor);

    void delete(Long id);

    void save(Professor professor);

}
